! function() {
    "use strict";

    function o(e) {
        return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function n(e, t) {
        for (var a = 0; a < t.length; a++) {
            var o = t[a];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o)
        }
    }

    function i(e, t, a) {
        return t in e ? Object.defineProperty(e, t, {
            value: a,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = a, e
    }

    function k(e) {
        return function(e) {
            if (Array.isArray(e)) return r(e)
        }(e) || function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
        }(e) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return r(e, t);
                var a = Object.prototype.toString.call(e).slice(8, -1);
                return "Map" === (a = "Object" === a && e.constructor ? e.constructor.name : a) || "Set" === a ? Array.from(e) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? r(e, t) : void 0
            }
        }(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function r(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var a = 0, o = new Array(t); a < t; a++) o[a] = e[a];
        return o
    }
    var m = "https://dycharts.com",
        w = !1,
        a = ["5544734748594536332", "7955555777700001301", "7955555777700001302", "7955555777700001303", "7955555777700001304"];

    function x(e) {
        return t = a, e = e.templateId, -1 < t.indexOf(e);
        var t
    }

    function s(e, t) {
        var a = 1 < arguments.length && void 0 !== t ? t : {
            key: null,
            pos: {
                row: null,
                col: null
            }
        };
        if ("7955555555502346001" !== e.templateId) {
            if ("5544734748594536484" === e.templateId) return f(e.props.colors.list);
            if ("single" === e.props.colors.type && "cross" === e.templateSwitch) return f(e.props.colors.list);
            var t = function(e) {
                    var a = [];
                    switch (e.templateSwitch) {
                        case "cross":
                            var o;
                            e.props.map[0][0].isLegend ? (a = _.unzip(e.dataSrc.data[0])[0].slice(1), w = !0) : (a = e.dataSrc.data[0][0].slice(1), w = !1, x(e) || (o = f(a), e.props.map[0].forEach(function(e, t) {
                                0 < t && !e.configurable && (o[t - 1] = void 0)
                            }), a = o.filter(function(e) {
                                return void 0 !== e
                            })));
                            break;
                        case "cross-time":
                            a = e.dataSrc.data[0][0].slice(1), w = !1, "154778232785223023" === e.templateId && (a = _.unzip(e.dataSrc.data[0])[0].slice(1), w = !0);
                            break;
                        case "obj-n-value-time":
                            var t = getPacketCircleChartMap(e);
                            a = _.unzip(e.dataSrc.data[0])[t] ? _.uniq(_.unzip(e.dataSrc.data[0])[t].slice(1)) : [], w = !0;
                            break;
                        case "key-value":
                            var n = B(e);
                            "5544734748594536330" === e.templateId ? (a.length = 2, a[0] = "收入", a[1] = "支出") : "7955555555502346003" === e.templateId ? (a = parseHistogramChartLegend(e)).length || (a.length = 1) : "154778171740391769" === e.templateId || "154777820323716078" === e.templateId || "154778145806026722" === e.templateId ? (a.length = 1, a[0] = _.unzip(e.dataSrc.data[0])[n][1]) : "444746070325460995" === e.templateId ? a = e.dataSrc.data[0][n].slice(1) : (a = _.unzip(e.dataSrc.data[0])[n].slice(1), w = !0);
                            break;
                        case "tree":
                        case "sunburst":
                            var n = e.dataSrc.data[0],
                                i = e.props.map[0],
                                i = solveDataHierarchyWithoutValue(n, i).root,
                                r = [];
                            "" !== i.name && r.push(i.name), i.children.forEach(function(e) {
                                r.push(e.name)
                            }), a = r;
                            break;
                        case "tree-value":
                            i = B(e);
                            a = _.uniq(_.unzip(e.dataSrc.data[0])[i]).slice(1);
                            break;
                        case "link-obj-valued":
                            var s = 0;
                            e.props.map[1].forEach(function(e) {
                                "typeCol" === e.function && (s = e.index)
                            }), a = _.uniq(_.unzip(e.dataSrc.data[1])[s]).slice(1);
                            break;
                        case "link-typed":
                        case "obj-type-value":
                            var l = B(e, "typeCol"),
                                d = B(e),
                                l = "number" == typeof l ? l : d;
                            a = _.uniq(_.unzip(e.dataSrc.data[0])[l]).slice(1), "5544734748594536487" === e.templateId && (a.length = 2);
                            break;
                        case "obj-n-value":
                            var c, p, d = 0;
                            d = "7955555555502346002" === e.templateId || "4612096174443311107" === e.templateId || "7955555777700001209" === e.templateId ? B(e, "typeCol") : B(e), ["7612096176663355103", "7955555666601234508", "7955555777700001501"].includes(e.templateId) ? (l = function(e) {
                                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "objCol";
                                return f(e).props.map[0].map(function(e) {
                                    if (e.function === t) return e.index
                                }).filter(function(e) {
                                    return void 0 !== e
                                })
                            }(e, "vCol"), c = e.dataSrc.data[0][0], a = l.map(function(e) {
                                return c[e]
                            }), w = !1) : "6543210123456536001" === e.templateId ? (a = e.dataSrc.data[0][d].slice(1).filter(function(e) {
                                return "最小值" !== e
                            }), w = !1) : "7955555777700001204" === e.templateId || "7955555777700001309" === e.templateId ? (a = e.dataSrc.data[0][0].slice(1), p = f(e.dataSrc.data[0][0]), a.length = 2, e.props.map[0].filter(function(e) {
                                return "vCol" === e.function
                            }).forEach(function(e, t) {
                                a[t] = (e.index, p[e.index])
                            }), w = !1) : "154777693253141239" === e.templateId || "7612096176663355104" === e.templateId || "7612096176663355105" === e.templateId ? _.unzip(e.dataSrc.data[0])[d] && (a = _.unzip(e.dataSrc.data[0])[d].slice(1), w = !0) : (_.unzip(e.dataSrc.data[0])[d] ? a = _.uniq(_.unzip(e.dataSrc.data[0])[d].slice(1)) : "linear" === e.props.colors.type ? a.length = 2 : a.length = 1, w = !0);
                            break;
                        case "sankey":
                            var u = [],
                                h = [],
                                m = B(e),
                                g = B(e, "targetCol");
                            e.dataSrc.data[0].forEach(function(e, t) {
                                0 < Number(t) && (u.push(e[m]), h.push(e[g]))
                            }), a = compact(uniq(flatten(zip(u, h))))
                    }
                    return a
                }(e),
                o = f(e.props.colors.list),
                n = t.length - o.length;
            if (n <= 0) t.length < 1 ? o.length = 0 : (-1 < ["154778171740391769", "154777820323716078", "154778145806026722"].indexOf(e.templateId) && (o.length = 2), !a.key || "obj-n-value" !== e.templateSwitch && "cross" !== e.templateSwitch || !w ? (o.length = t.length, e.props.pictures && e.props.pictures.svglist && (e.props.pictures.svglist.length = t.length)) : (i = 0 === a.pos.row ? 0 : a.pos.row - 1, o.splice(i, 1), e.props.pictures && e.props.pictures.svglist && e.props.pictures.splice(i, 1)));
            else if (a.key && null !== w) {
                var i = w ? "row" : "col",
                    a = 0 === a.pos[i] ? 0 : a.pos[i] - 1;
                o.splice(a, 0, 0), e.props.pictures && e.props.pictures.urlList && ((i = f(e.props.pictures.urlList)).splice(a, 0, null), e.props.pictures.urlList = i), e.props.pictures && e.props.pictures.svglist && ((r = f(e.props.pictures.svglist)).splice(a, 0, e.props.pictures.svglist[0]), e.props.pictures.svglist = r)
            } else {
                var r = f(o),
                    s = 0 < r.length ? r.pop() : -1;
                if ("number" == typeof s)
                    for (var l = 0; l < n; l++) {
                        var d = s + l + 1;
                        14 < d && (d = g(d)), o.push(d)
                    } else
                        for (var c = 0; c < n; c++) {
                            var p = c;
                            14 < c && (p = g(c)), o.push(p)
                        }
                if (e.props.pictures && e.props.pictures.svglist) {
                    for (var u = f(e.props.pictures.svglist), h = 0; h < n; h++) u.push(e.props.pictures.svglist[0]);
                    e.props.pictures.svglist = u
                }
            }
            return e.props.colors.list = o, e.props.colors.list
        }
    }

    function g(e) {
        return e = e % 15 == 0 ? 0 : Math.abs(e - 15 * Math.floor(e / 15))
    }

    function l(o) {
        return new Promise(function(t, a) {
            var e = new XMLHttpRequest;
            e.open("GET", o, !0), e.onreadystatechange = function() {
                var e;
                4 === this.readyState && (200 === this.status ? t(JSON.parse(this.responseText), this) : (e = {
                    code: this.status,
                    response: this.response
                }, a(e, this)))
            }, e.send()
        })
    }

    function f(e) {
        var t, a = e instanceof Array ? [] : null === e ? null : {};
        for (t in e) a[t] = "object" === o(e[t]) ? f(e[t]) : e[t];
        return a
    }

    function y(e) {
        if (!e) throw new Error("need request address");
        var t, a;
        return 0 < e.indexOf("_") ? "d" === (a = e.split("_")[0]) ? t = "".concat(m, "/vis/dychart/data_chart_publish/").concat(e.split("_")[1]) : "c" === a && (t = "".concat(m, "/vis/share/chart_publish/").concat(e.split("_")[1])) : t = "".concat(m, "/vis/share/publish/").concat(e), t
    }

    function v(e) {
        var o = {};
        return e.replace(/[?&](.*?)=([^&]*)/g, function(e, t, a) {
            return o[t] = a
        }), o
    }

    function b() {
        return /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)
    }

    function C() {
        var e = navigator.userAgent;
        return -1 < e.indexOf("Opera") || -1 < e.indexOf("OPR") ? "Opera" : -1 < e.indexOf("compatible") && -1 < e.indexOf("MSIE") ? "IE" : -1 < e.indexOf("Edge") ? "Edge" : -1 < e.indexOf("Firefox") ? "Firefox" : -1 < e.indexOf("Safari") && -1 == e.indexOf("Chrome") ? "Safari" : -1 < e.indexOf("Chrome") && -1 < e.indexOf("Safari") ? "Chrome" : window.ActiveXObject || "ActiveXObject" in window ? "IE>=11" : "Unkonwn"
    }

    function d(e, t, a) {
        var o, n, i = document.createElement("div"),
            r = /(wxwork|Wxwork|WXwork|wxWork)/.test(window.navigator.userAgent);
        e && "not-found" === e ? (i.innerHTML = '\n      <div class="not-found-box">\n        <img class="lock" alt="" src="./images/not-find.svg">\n        <div class="modal-title">此项目链接已失效，目前无法访问</div>\n      </div>\n    ', i.className = "project-modal", document.querySelector("body").appendChild(i)) : e && "password" === e ? document.querySelector(".project-modal") ? document.querySelector(".project-modal").style.display = "flex" : (i.innerHTML = '\n      <div class="password-box">\n        <img class="lock" alt="" src="./images/lock.svg">\n        <div class="modal-title">此项目已加密，请输入密码后查看</div>\n        <input placeholder="请输入密码" type="password"/>\n        <p class="msg"></p>\n        <button>打开</button>\n      </div>\n      ', i.className = "project-modal", document.querySelector("body").appendChild(i)) : e && "no-permission" === e && l("".concat(m, "/vis/auth/users/me/")).then(function(e) {
            var t = e.data;
            !e || 1e3 !== e.resultCode || r && !t.wxqy_corp_id ? b() ? l(function() {
                var e, t, a = v(location.href).id;
                if (!a) throw new Error("need request address");
                return 0 < a.indexOf("_") ? "d" === (t = a.split("_")[0]) ? e = "".concat(m, "/vis/dychart/publish_project_source/infographic/").concat(a.split("_")[1]) : "c" === t && (e = "".concat(m, "/vis/dychart/publish_project_source/chart/").concat(a.split("_")[1])) : e = "".concat(m, "/vis/dychart/publish_project_source/infographic/").concat(a), e
            }()).then(function(e) {
                e.data.is_qywx_project && !r ? (i.innerHTML = '\n                <div class="wxWork-tip">\n                  <h5>提示</h5>\n                  <p>该网页由企业微信内部应用发出，请在企<br/>业微信客户端内访问</p>\n                  <img src="./images/wxWork.svg">\n                </div>\n              ', i.className = "project-modal mobile", document.querySelector("body").appendChild(i)) : (window._hmt.push(["_trackEvent", "xshow", "checkAuth", "pageShow"]), i.innerHTML = '\n                <div class="user-nologin">\n                  <img class="lock" alt="" src="./images/lock.svg">\n                  <div class="modal-title">此项目已设权限，请登录后查看</div>\n                  <button>立即登录</button>\n                </div>\n              ', i.className = "project-modal", document.querySelector("body").appendChild(i), document.querySelector(".user-nologin button").addEventListener("click", function() {
                    window._hmt.push(["_trackEvent", "xshow", "checkAuth", "back2Login"]), location.href = "".concat(m, "/vis/auth/signin.html?redirect=").concat(location.href)
                }))
            }) : (window._hmt.push(["_trackEvent", "xshow", "checkAuth", "pageShow"]), i.innerHTML = '\n            <div class="user-nologin">\n              <img class="lock" alt="" src="./images/lock.svg">\n              <div class="modal-title">此项目已设权限，请登录后查看</div>\n              <button>立即登录</button>\n            </div>\n          ', i.className = "project-modal", document.querySelector("body").appendChild(i), document.querySelector(".user-nologin button").addEventListener("click", function() {
                window._hmt.push(["_trackEvent", "xshow", "checkAuth", "back2Login"]), location.href = "".concat(m, "/vis/auth/signin.html?redirect=").concat(location.href)
            })) : (window._hmt.push(["_trackEvent", "xshow", "NoAuth", "pageShow"]), i.innerHTML = '\n          <div class="user-nopermission">\n            <img class="lock" alt="" src="./images/lock.svg">\n            <div class="modal-title">当前账号无查看权限</div>\n            '.concat(r ? "" : "<button>返回首页</button>", "\n          </div>\n        "), i.className = "project-modal", document.querySelector("body").appendChild(i), document.querySelector(".user-nopermission button").addEventListener("click", function() {
                window._hmt.push(["_trackEvent", "xshow", "NoAuth", "back2Home"]), t && t.team_id ? location.href = "".concat(m, "/appv2/#/pages/enterprise/index") : location.href = "".concat(m, "/appv2/#/pages/home/index")
            }))
        }), e && "password" === e && (o = document.querySelector(".password-box input"), n = document.querySelector(".password-box .msg"), e = document.querySelector(".password-box button"), o.addEventListener("keyup", function(e) {
            "" === e.target.value ? (n.innerHTML = "请输入密码", $(o).addClass("error"), $(n).addClass("active")) : ($(n).removeClass("active"), $(o).removeClass("error"))
        }), e.addEventListener("click", function() {
            "" !== o.value ? l("".concat(t, "?password=").concat(o.value)).then(function(e) {
                6004 === e.resultCode ? (n.innerHTML = "访问密码出错", $(n).addClass("active"), $(o).addClass("error"), i.style.display = "flex") : 1e3 === e.resultCode && (i.style.display = "none", window.scrollTo(0, 0), e.password = o.value, a && a(e), o.value = "", $(n).removeClass("active"), $(o).removeClass("error"))
            }).catch(function(e) {
                console.log(e)
            }) : (n.innerHTML = "请输入密码", $(n).addClass("active"), $(o).addClass("error"))
        }))
    }

    function c(e, t, a) {
        "chart" === t.type && ("cross-time" === t.templateSwitch || "obj-n-value-time" === t.templateSwitch ? "boolean" == typeof e ? function(e, t, a) {
            a = a.props.animation.transition;
            e ? (t.transition(a), t.onInterruptChange(!1)) : (t.transition(a), t.onInterruptChange(!0))
        }(e, t.d3Chart, a) : void 0 === e ? t.d3Chart.onCleanTimer() : 1 === e ? p(!0, t) : t.d3Chart.onTimeChange(e) : (e && this.componentRef.instance.echart && p(!0, t), !e && this.componentRef.instance.echart && p(!1, t)))
    }

    function p(e, t) {
        e = !(0 < arguments.length && void 0 !== e) || e, t = 1 < arguments.length ? t : void 0;
        e ? t.d3Chart.setOption(t) : t.d3Chart.onInterruptChange()
    }

    function u(e) {
        e = e.split(":");
        return 60 * parseInt(e[0]) + parseInt(e[1])
    }

    function I(e) {
        var t = parseInt(e),
            e = Math.floor(t / 60 % 60) < 10 ? "0" + Math.floor(t / 60 % 60) : Math.floor(t / 60 % 60),
            t = Math.floor(t % 60) < 10 ? "0" + Math.floor(t % 60) : Math.floor(t % 60);
        return "".concat(e, ":").concat(t)
    }

    function S() {
        return {
            playing: !1,
            startTime: "00:00",
            endTime: "04:25",
            curTime: 0,
            loopback: !1,
            autoplay: !1,
            startSecond: 0
        }
    }

    function B(e, t) {
        var a = 1 < arguments.length && void 0 !== t ? t : "objCol",
            o = 0;
        return e.props.map[0].forEach(function(e) {
            e.function === a && (o = e.index)
        }), o
    }

    function T(e) {
        return ~e.indexOf(",") ? (t = JSON.parse(e.replace(RegExp("'", "g"), '"')), a = t.length, o = "", function(e) {
            for (var t = k(e), a = 0; a < t.length - 2; a++)
                for (var o, n = 0; n < t.length - 2 - a; n++) Number(t[n].split(":")[1]) > Number(t[n + 1].split(":")[1]) && (o = t[n], t[n] = t[n + 1], t[n + 1] = o);
            return t
        }(t).map(function(e) {
            e.indexOf("angle") < 0 && (o += "".concat(h(e.split(":")[0], !1), " ").concat(function(e) {
                if (0 == e) return 0;
                e = Number(100 * Number(e)).toFixed(2);
                return e += "%"
            }(e.split(":")[1]), ","))
        }), o = o.substring(0, o.length - 1), "linear-gradient(".concat(Number(t[a - 1].split(":")[1]) + 90, "deg, ").concat(o, ")")) : String(h(e));
        var t, a, o
    }

    function h(e, t) {
        var t = 1 < arguments.length && void 0 !== t && t,
            a = e.toLowerCase();
        if (a && /^#([0-9a-fA-f]{8}|[0-9a-fA-f]{6}|[0-9a-fA-f]{3})$/.test(a)) {
            4 === a.length && (a = a[0] + a[1] + a[1] + a[2] + a[2] + a[3] + a[3]);
            for (var o, n = [], i = 1; i < 9; i += 2) 7 == i ? (o = (parseInt("0x" + a.slice(i, i + 2)) / 255).toFixed(2), n.push(o)) : n.push(parseInt("0x" + a.slice(i, i + 2)));
            return t ? (n[3] || n.push(1), n) : 9 == e.length ? "rgba(" + n.join(",") + ")" : "rgb(" + n.slice(0, 3).join(",") + ")"
        }
        return a
    }
    var L = [{
            blockId: "",
            templateId: "666666666666666666",
            title: "矩形",
            path: [],
            type: "shape",
            openGradient: !1,
            position: {
                left: 60,
                top: 80
            },
            shapeType: "rectangle",
            props: {
                size: {
                    height: "200",
                    width: "300",
                    rotate: "0"
                },
                specified: {
                    rx: 0,
                    ry: 0,
                    x: 0,
                    y: 0
                },
                fill: {
                    fillColor: ["#08aded", "#08aded"],
                    width: "300",
                    height: "200"
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "default",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "圆角矩形",
            path: [],
            type: "shape",
            openGradient: !1,
            position: {
                left: 60,
                top: 80
            },
            shapeType: "round-rectangle",
            props: {
                size: {
                    height: "200",
                    width: "300",
                    rotate: "0"
                },
                specified: {
                    rx: 15,
                    ry: 15,
                    x: 0,
                    y: 0
                },
                fill: {
                    fillColor: ["#08aded", "#08aded"],
                    width: "300",
                    height: "200"
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "default",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "圆形",
            path: [],
            type: "shape",
            openGradient: !1,
            position: {
                left: 60,
                top: 80
            },
            shapeType: "oval",
            props: {
                size: {
                    height: "200",
                    width: "200",
                    rotate: "0",
                    ratio: !0
                },
                specified: {
                    cx: 100,
                    cy: 100,
                    rx: 100,
                    ry: 100
                },
                fill: {
                    fillColor: ["#08aded", "#08aded"],
                    width: "200",
                    height: "200"
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "defaultd",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "三角形",
            path: "100, 0 0, 200 200, 200",
            type: "shape",
            openGradient: !1,
            position: {
                left: 60,
                top: 80
            },
            shapeType: "triangle",
            props: {
                size: {
                    height: "200",
                    width: "200",
                    rotate: "0"
                },
                fill: {
                    fillColor: ["#08aded", "#08aded"]
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "defaultd",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "五边形",
            path: "128,0, 256,97, 216,244, 38, 244, 0,97",
            type: "shape",
            openGradient: !1,
            position: {
                left: 60,
                top: 80
            },
            shapeType: "pentagon",
            props: {
                size: {
                    height: "244",
                    width: "256",
                    rotate: "0"
                },
                fill: {
                    fillColor: ["#08aded", "#08aded"]
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "defaultd",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "直线",
            path: "75,0, 150,55, 120,150, 30,150, 0,55",
            arrowLeftPath: "M10,2 L2,6 L10,10 L6,6 L10,2",
            arrowRightPath: "M2,2 L10,6 L2,10 L6,6 L2,2",
            type: "shape",
            dragPosition: {
                oneLeft: 0,
                oneTop: 0,
                twoLeft: 195,
                twoTop: 0
            },
            shapeType: "line",
            props: {
                size: {
                    height: "12",
                    width: "207",
                    rotate: "0"
                },
                specified: {
                    x1: "5",
                    y1: "5",
                    x2: "200",
                    y2: "5"
                },
                fill: {
                    fillColor: ["#08aded"]
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "#08aded",
                strokeType: "defaultd",
                strokeDasharray: 0,
                strokeWidth: 2,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }, {
            blockId: "",
            templateId: "666666666666666666",
            title: "图标",
            path: "",
            type: "shape",
            src: "",
            position: {
                left: 60,
                top: 80
            },
            shapeType: "icon",
            props: {
                size: {
                    height: "100",
                    width: "100",
                    rotate: "0"
                },
                fill: {
                    fillColor: ["#08aded"]
                },
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                opacity: 100,
                strokeColor: "transparent",
                strokeType: "defaultd",
                strokeWidth: 0,
                strokeDasharray: 0,
                tooltip: !1,
                tooltipText: null,
                shadowColor: "#c6c6c6",
                shadowRadius: 3,
                shadowAngle: 30,
                shadowBlur: 5
            }
        }],
        E = {
            blockId: "",
            templateId: "222222222222222222",
            title: "图片",
            type: "image",
            position: {
                left: 60,
                top: 80
            },
            src: "http://placehold.it/300x200",
            props: {
                size: {
                    height: "200",
                    width: "300",
                    rotate: "0"
                },
                opacity: 100,
                borderRadius: 0,
                tooltip: !1,
                tooltipText: null,
                shadow: {
                    display: !1,
                    shadowColor: "#c6c6c6",
                    shadowRadius: 3,
                    shadowAngle: 45,
                    shadowBlur: 5,
                    shadowOpacity: 100
                },
                mask: {
                    retangle: {},
                    shape: {}
                },
                border: {
                    strokeColor: "#ffffff",
                    strokeType: "solid",
                    strokeWidth: 0
                }
            }
        },
        q = null,
        M = [],
        A = [],
        D = new(function() {
            function h(e) {
                var r = this;
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, h);
                var t = this;
                window.d3Chart.setUserMd("c53822d351882c0c49acafc7c44f09ca");
                var a, o, n, i, s, l, d = {};

                function c() {
                    var e = s.getBoundingClientRect().width;
                    (o = o || 540) < e && (e = o), l.innerHTML = "html{font-size:" + 100 * e / a + "px;}"
                }
                pageConfig.usingLocalData || (d = {
                    url: y(v(location.href).id),
                    type: v(location.href).type,
                    preview: v(location.href).preview,
                    page: v(location.href).page - 1,
                    hidelogo: v(location.href).hidelogo,
                    hidewatermark: v(location.href).hidewatermark,
                    sectionHeight: "",
                    sectionWidth: "",
                    hideToolbar: v(location.href).hideToolbar,
                    partner_logo: "",
                    isScroll: !1,
                    isScrollfullWidth: !1,
                    isScrollfullHeight: !1,
                    dataClass: {},
                    autoplayList: [],
                    d3ChartAnimestat: !1,
                    refresh_rate: !1,
                    scaleNum: 1,
                    scaleNumTotal: 1,
                    heiNum: null,
                    pageScale: 0,
                    article: null,
                    ismove: !1,
                    ishover: !1,
                    settimerMove: null,
                    payData: {},
                    interval: null,
                    result: null,
                    isHaveReload: !1,
                    oldData: {},
                    pageList: [],
                    pageboxList: [],
                    currentPageIndex: 0,
                    hideDomInterval: null
                }), pageConfig.usingLocalData || window._hmt.push(["_trackPageview", "/xshow/index.html?id=*"]), this.opts = Object.assign({}, e, d), (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)) && (o = a = 750, i = document, p = window, s = i.documentElement, l = document.createElement("style"), s.firstElementChild ? s.firstElementChild.appendChild(l) : ((d = i.createElement("div")).appendChild(l), i.write(d.innerHTML), d = null), c(), p.addEventListener("resize", function() {
                    clearTimeout(n), n = setTimeout(c, 300)
                }, !1), p.addEventListener("pageshow", function(e) {
                    e.persisted && (clearTimeout(n), n = setTimeout(c, 300))
                }, !1), "complete" === i.readyState ? i.body.style.fontSize = "16px" : i.addEventListener("DOMContentLoaded", function(e) {
                    i.body.style.fontSize = "16px"
                }, !1), document.querySelector("body").classList.add("is-mobile")), this.reloadPage(), this.opts.hideDomFun = function() {
                    clearInterval(r.opts.hideDomInterval), r.opts.hideDomInterval = setInterval(function() {
                        var e = document.querySelector("header");
                        !r.opts.ishover && !r.opts.ismove || "none" !== e.style.display || $("main").hasClass("iframe-main") ? r.opts.preview || (document.querySelector(".util-box-full").style.display = "none") : document.querySelector(".util-box-full").style.display = "flex";
                        var t = !!(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement);
                        self == top && !t || !r.opts.ishover && !r.opts.ismove || "none" !== e.style.display ? !t && self == top || ($(".swiper-container .swiper-button-next").hide(), $(".swiper-container .swiper-button-prev").hide()) : ($(".content-wrapper").children().length - 1 == q.activeIndex ? $(".swiper-container .swiper-button-next").hide() : $(".swiper-container .swiper-button-next").show(), 0 == q.activeIndex ? $(".swiper-container .swiper-button-prev").hide() : $(".swiper-container .swiper-button-prev").show())
                    }, 200)
                }, self != top && setTimeout(function() {
                    r.opts.hideDomFun()
                }, 1e3), document.addEventListener("mousemove", function(e) {
                    document.querySelector(".util-box-full");
                    var t = document.querySelector("header");
                    t && "none" !== t.style.display || (r.opts.ismove = !0), clearTimeout(r.opts.settimerMove), r.opts.settimerMove = setTimeout(function() {
                        r.opts.ismove = !1
                    }, 500)
                }), document.querySelector(".full-page").addEventListener("click", function() {
                    window._hmt.push(["_trackEvent", "xshow", "top-FullScreen", "clickFullScreen"]);
                    var e = !!(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement),
                        a = t.opts.result.data.article.contents.design;
                    e ? t.exitFullscreen() : (t.fullScreen(), document.getElementById("scale-number-full").innerHTML = "100%", document.querySelector(".util-box-full").style.display = "flex", document.querySelector("header").style.display = "none", document.querySelector("footer").style.display = "none", document.querySelector("main").style.paddingBottom = "0", "E" === t.opts.result.data.origin && $(".page-logo").hide(), $("article").css({
                        width: "",
                        height: "",
                        marginTop: 0,
                        padding: 0,
                        backgroundColor: $(".swiper-slide section .page").hasClass("infographic") ? "#434343" : "f4f3f5"
                    }), H(), setTimeout(function() {
                        var e = $(window).width(),
                            t = $(window).height();
                        (a.width / a.height >= e / t && !b() ? $("#transverse-full") : $("#portrait-full")).click()
                    }, 30)), t.opts.hideDomFun()
                });
                var p = "";

                function u(e) {
                    e <= 30 ? ($("#reduce").addClass("active"), $("#reduce").find("img").attr("src", "./images/reduceN.svg "), $("#add").removeClass("active"), $("#add").find("img").attr("src", "./images/add.svg ")) : 200 <= e ? ($("#reduce").removeClass("active"), $("#reduce").find("img").attr("src", "./images/reduce.svg "), $("#add").addClass("active"), $("#add").find("img").attr("src", "./images/addN.svg ")) : ($("#reduce").removeClass("active"), $("#reduce").find("img").attr("src", "./images/reduce.svg "), $("#add").removeClass("active"), $("#add").find("img").attr("src", "./images/add.svg "))
                }
                p = "Chrome" === C() ? "fullscreenchange" : "webkitfullscreenchange", document.addEventListener(p, function(e) {
                    !(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement) && (document.querySelector(".out-full-page").click(), document.querySelector("header").style.display = "flex", t.opts.partner_logo ? document.querySelector("footer").style.display = "none" : document.querySelector("footer").style.display = "block", document.querySelector("main").style.backgroundColor = "initial", t.opts.preview || (document.querySelector(".util-box-full").style.display = "none"), t.opts.sectionHeight = $(".swiper-slide-active section")[0].getBoundingClientRect().height, t.opts.sectionWidth = $(".swiper-slide-active section")[0].getBoundingClientRect().width)
                }), document.querySelector("footer").querySelector("a").addEventListener("click", function() {
                    v(location.href).id && "c" === v(location.href).id.split("_")[0] ? window._hmt.push(["_trackEvent", "xshow", "bottom-chart", "navigation"]) : window._hmt.push(["_trackEvent", "xshow", "bottom-info", "navigation"])
                }), document.getElementById("reduce").addEventListener("click", function(e) {
                    var t, a, o, n, i;
                    $("#reduce").hasClass("active") || (t = document.getElementById("scale-number").innerHTML, t = Number(t.substring(0, t.length - 1)), (t -= 25) <= 30 && (t = 30, $("#reduce").addClass("active"), $("#reduce").find("img").attr("src", "./images/reduceN.svg ")), $("#add").removeClass("active"), $("#add").find("img").attr("src", "./images/add.svg "), document.getElementById("scale-number").innerHTML = t + "%", t /= 100, a = r.opts.result.data.article.contents.design, i = n = 0, o = $(window).width(), i = (n = parseInt(a.width) >= o && !b() ? o - 24 : b() ? o : a.width) / a.width, $(".swiper-slide section .page").css("transform", "scale(" + i + ")"), $(".swiper-slide section").css({
                        width: n,
                        height: i * a.height
                    }), R(t + (1 - (r.opts.pageScale = i))))
                }), document.getElementById("add").addEventListener("click", function(e) {
                    var t, a, o, n, i;
                    $("#add").hasClass("active") || (t = document.getElementById("scale-number").innerHTML, t = Number(t.substring(0, t.length - 1)), 200 <= (t += 25) && (t = 200, $("#add").addClass("active"), $("#add").find("img").attr("src", "./images/addN.svg ")), $("#reduce").removeClass("active"), $("#reduce").find("img").attr("src", "./images/reduce.svg "), document.getElementById("scale-number").innerHTML = t + "%", t /= 100, a = r.opts.result.data.article.contents.design, i = n = 0, o = $(window).width(), i = (n = parseInt(a.width) >= o && !b() ? o - 24 : b() ? o : a.width) / a.width, $(".swiper-slide section .page").css("transform", "scale(" + i + ")"), $(".swiper-slide section").css({
                        width: n,
                        height: i * a.height
                    }), R(t + (1 - (r.opts.pageScale = i))))
                }), document.getElementById("transverse").addEventListener("click", function() {
                    var e = function() {
                        var e = this.opts.result.data.article.contents.design,
                            t = $(window).width(),
                            a = 0,
                            o = 0,
                            n = null,
                            i = parseInt(v(location.href).height),
                            n = this.opts.type ? {
                                width: a = 544,
                                height: (o = a / e.width) * e.height
                            } : i ? {
                                width: (o = i / e.height) * e.width,
                                height: i
                            } : {
                                width: a = t - 24,
                                height: (o = a / e.width) * e.height
                            };
                        $(".swiper-slide .page").css("transform", "scale(" + o + ")"), $(".swiper-slide section").css(n), document.getElementById("scale-number").innerHTML = Math.floor(100 * o) + "%", R((this.opts.pageScale = o) + (1 - o)), u(Math.floor(100 * o))
                    }.bind(r);
                    e(), setTimeout(function() {
                        e()
                    }, 300)
                }), document.getElementById("portrait").addEventListener("click", function() {
                    var e = function() {
                        var e = $("footer").height(),
                            t = this.opts.result.data.article.contents.design,
                            a = $(window).height() - 60 - e - 24,
                            e = a / t.height;
                        $(".swiper-slide .page").css("transform", "scale(" + e + ")"), document.getElementById("scale-number").innerHTML = Math.floor(100 * e) + "%", $(".swiper-slide section").css("width", e * t.width), $(".swiper-slide section").css("height", a), this.opts.pageScale = e, u(Math.floor(100 * e)), R(1)
                    }.bind(r);
                    e(), setTimeout(function() {
                        e()
                    }, 300)
                }), $(".util-box").on("click", ".drop-num", function(e) {
                    e = Number(e.target.innerText.split("%")[0]) / 100;
                    $("#reduce").removeClass("active"), $("#reduce").find("img").attr("src", "./images/reduce.svg "), $("#add").removeClass("active"), $("#add").find("img").attr("src", "./images/add.svg "), e <= .3 && ($("#reduce").addClass("active"), $("#reduce").find("img").attr("src", "./images/reduceN.svg ")), 2 <= e && ($("#add").addClass("active"), $("#add").find("img").attr("src", "./images/addN.svg ")), r.setPageTransform(e)
                }), document.getElementById("scale-number").addEventListener("click", function() {
                    "block" === document.querySelector(".util-box").querySelector(".dropdowns").style.display ? document.querySelector(".util-box").querySelector(".dropdowns").style.display = "none" : document.querySelector(".util-box").querySelector(".dropdowns").style.display = "block"
                }), document.getElementById("reduce-full").addEventListener("click", function() {
                    var e, t, a, o, n;
                    $("#reduce-full").hasClass("active") || (e = document.getElementById("scale-number-full").innerHTML, e = Number(e.substring(0, e.length - 1)), (e -= 25) <= 30 && (e = 30, $("#reduce-full").addClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduceN.svg ")), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg "), document.getElementById("scale-number-full").innerHTML = e + "%", e /= 100, t = r.opts.result.data.article.contents.design, n = o = 0, a = $(window).width(), n = (o = parseInt(t.width) >= a ? a : t.width) / t.width, $(".swiper-slide section .page").css("transform", "scale(" + n + ")"), $(".swiper-slide section").css({
                        width: o,
                        height: n * t.height
                    }), R(e + (1 - (r.opts.pageScale = n))))
                }), document.getElementById("add-full").addEventListener("click", function() {
                    var e, t, a, o, n;
                    $("#add-full").hasClass("active") || (e = document.getElementById("scale-number-full").innerHTML, e = Number(e.substring(0, e.length - 1)), 200 <= (e += 25) && (e = 200, $("#add-full").addClass("active"), $("#add-full").find("img").attr("src", "./images/addN.svg ")), $("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), document.getElementById("scale-number-full").innerHTML = e + "%", e /= 100, t = r.opts.result.data.article.contents.design, n = o = 0, a = $(window).width(), n = (o = parseInt(t.width) >= a ? a : t.width) / t.width, $(".swiper-slide section .page").css("transform", "scale(" + n + ")"), $(".swiper-slide section").css({
                        width: o,
                        height: n * t.height
                    }), R(e + (1 - (r.opts.pageScale = n))))
                }), document.getElementById("transverse-full").addEventListener("click", this.transverseFullClick.bind(this)), document.getElementById("portrait-full").addEventListener("click", this.portraitFullClick.bind(this)), document.querySelector(".out-full-page").addEventListener("click", function() {
                    t.opts.preview && window.parent.postMessage("closePreviewIframe", "*"), document.querySelector(".util-box-full").style.display = "none", document.querySelector("main").style.minHeight = "calc(100% - " + $("footer").height() + "px)", (document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement) && t.exitFullscreen(), $(".page-logo").show(), $("article").removeAttr("style"), H(), setTimeout(function() {
                        r.updatePageSize()
                    }, 30), clearInterval(r.opts.hideDomInterval)
                }), $(".util-box-full").on("mouseover", function() {
                    r.opts.ishover = !0
                }), $(".util-box-full").on("mouseout", function() {
                    r.opts.ishover = !1
                }), $(".util-box-full").on("click", ".drop-num", function(e) {
                    e = Number(e.target.innerText.split("%")[0]) / 100;
                    $("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg "), e <= .3 && ($("#reduce-full").addClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduceN.svg ")), 2 <= e && ($("#add-full").addClass("active"), $("#add-full").find("img").attr("src", "./images/addN.svg ")), r.setPageTransformFull(e)
                }), document.getElementById("scale-number-full").addEventListener("click", function() {
                    "block" === document.querySelector(".util-box-full").querySelector(".dropdowns").style.display ? (document.querySelector(".util-box-full").querySelector(".dropdowns").style.display = "none", document.querySelector(".util-box-full").querySelector(".util").style.display = "", document.querySelector(".util-box-full").querySelector(".util-small").style.display = "", document.querySelector(".util-box-full").querySelector(".util").style.marginLeft = "") : (document.querySelector(".util-box-full").querySelector(".dropdowns").style.display = "block", document.querySelector(".util-box-full").querySelector(".util").style.display = "flex", document.querySelector(".util-box-full").querySelector(".util").style.marginLeft = "-216px", document.querySelector(".util-box-full").querySelector(".util-small").style.display = "none")
                }), document.addEventListener("click", function(e) {
                    "block" === document.querySelector(".util-box-full").querySelector(".dropdowns").style.display && "scale-number-full" !== e.target.id && (document.querySelector(".util-box-full").querySelector(".dropdowns").style.display = "none", document.querySelector(".util-box-full").querySelector(".util").style.display = "", document.querySelector(".util-box-full").querySelector(".util-small").style.display = "", document.querySelector(".util-box-full").querySelector(".util").style.marginLeft = ""), "block" === document.querySelector(".util-box").querySelector(".dropdowns").style.display && "scale-number" !== e.target.id && (document.querySelector(".util-box").querySelector(".dropdowns").style.display = "none")
                }), window.self !== window.top && this.resolveIframePage(), pageConfig.hideToolbar && (document.querySelector(".util-box").style.display = "none")
            }
            var e, t, a;
            return e = h, (t = [{
                key: "reloadPage",
                value: function() {
                    var t = this;
                    pageConfig.usingLocalData ? t.resolveArticle(block) : t.opts.preview ? window.addEventListener("message", function(e) {
                        e && e.data && (e = e.data, t.opts.result = e, t.setPayData(e))
                    }, !1) : l(this.opts.url).then(function(e) {
                        (t.opts.result = e) && 1e3 === e.resultCode ? t.setPayData(e) : 6003 === e.resultCode || 6004 === e.resultCode ? (clearInterval(t.opts.interval), d("password", t.opts.url, function(e) {
                            t.opts.url = y(v(location.href).id) + "?password=".concat(e.password), t.opts.result = e, t.setPayData(e)
                        })) : 3001 === e.resultCode ? d("not-found", "") : 6001 === e.resultCode && d("no-permission", "")
                    })
                }
            }, {
                key: "setPayData",
                value: function(t) {
                    var e, a = this,
                        o = v(location.href).id.includes("c_") ? "chart" : "project";
                    !a.opts.interval && t.data.refresh_rate ? (clearInterval(a.opts.interval), a.opts.interval = setInterval(function() {
                        a.opts.isHaveReload = !0, a.opts.refresh_rate = !0, a.reloadPage(), A = []
                    }, 6e4 * t.data.refresh_rate)) : a.opts.interval && !t.data.refresh_rate && clearInterval(a.opts.interval), "E" === t.data.origin || null !== t.data.ctor_lv || this.opts.type ? 1e3 === t.resultCode && (a.opts.payData.resultCode = 88801, "datastore" === a.opts.pageType ? a.resolveDataStoreArticle(a.opts.pageType, t.data) : a.resolveArticle(t.data)) : l((e = t.data.id, o = o, "".concat(m, "/vis/share/v2/showprojectneedpay?type=").concat(o, "&project=").concat(e))).then(function(e) {
                        a.opts.payData = e, 1e3 === t.resultCode && ("datastore" === a.opts.pageType ? a.resolveDataStoreArticle(a.opts.pageType, t.data) : a.resolveArticle(t.data))
                    })
                }
            }, {
                key: "resolveArticle",
                value: function(e) {
                    var a = this;
                    $(".content-wrapper").html(""), this.opts.pageList = [], this.opts.pageboxList = [];
                    var t, o, n = e;
                    this.opts.article = e.article, document.title = "" === n.title ? "未命名" : n.title, document.querySelector(".title").innerHTML = document.title, $(".project-description").html(n.description || ""), 1 == n.article.contents.pages.length && ($("main header .util-box").width(349), $(".u-gridding").hide(), $("#gridding").hide()), $("#gridding span").html(n.article.contents.pages.length), $(".u-gridding span").html(n.article.contents.pages.length), $(".m-selectPage h3").html(document.title), v(location.href).id && "c" === v(location.href).id.split("_")[0] && Number(n.article.contents.design.height) === Number(n.article.contents.pages[0].blocks[0].props.size.height) && n.article.contents.pages[0].blocks[0].props.logoDisplay && (n.article.contents.pages[0].blocks[0].props.logoDisplay.show || n.article.contents.pages[0].blocks[0].props.publishDisplay.show) && (o = "32" === (t = n.article.contents.pages[0].blocks[0].props).logoDisplay.imgHeight ? "18" : "15", o = ~~t.logoDisplay.imgHeight + ~~t.logoDisplay.topLineHeight + ~~t.logoDisplay.bottomLineHeight - ~~o, t.mapPosition && !t.mapPosition.canAdjust || (n.article.contents.design.height = o + ~~t.size.height + "")), this.resolveDesign(n.article.contents), this.reloadBlocksInPages(n.article.contents.pages), this.setPageCss(n);
                    var i, r = e.article.contents.bgm;
                    r && r.pageIndex.forEach(function(e, t) {
                        a.resolveSong(r, t)
                    }), this.updatePageSize(), setTimeout(function() {
                        H(), $(".m-loading").hide()
                    }, 30), this.opts.type ? ($("header").hide(), $("footer").hide(), $("body").addClass("ppt"), $(".m-thumbs").addClass("active"), setTimeout(function() {
                        $(".swiper-slide").each(function(e, t) {
                            $(".m-thumbs ul").append('<li class="'.concat(0 == e ? "active" : "", '" data-index="').concat(e, '">\n        <div class="border">').concat($(t).html(), "</div>\n      </li>"))
                        }), $(".m-thumbs li").on("click", function() {
                            var e = $(this).attr("data-index");
                            $(".m-thumbs li").removeClass("active"), $(this).addClass("active"), q.activeIndex = e, $(".swiper-wrapper").css("transition-duration", "0s"), P(), setTimeout(function() {
                                $(".swiper-wrapper").css("transition-duration", "0.3s")
                            }, 10), H()
                        }), F(), P();
                        var e = $(".m-thumbs ul").outerWidth();
                        $(window).width() - 40 < e && $(".m-thumbs .bt-next").show()
                    }, 300)) : (this.addEventWX(n), this.opts.isHaveReload || this.setIsscroll(), b() && (document.querySelector("main").style.justifyContent = "normal", this.getUserInfo(n)), this.reloadBlocksForPPT()), this.opts.preview && (i = this, document.getElementById("scale-number-full").innerHTML = "100%", document.querySelector(".util-box-full").style.display = "flex", document.querySelector("header").style.display = "none", document.querySelector("footer").style.display = "none", document.querySelector("main").style.paddingBottom = "0", $(".page-logo").hide(), $("article").css({
                        width: "",
                        height: "auto",
                        margin: 0,
                        padding: 0,
                        backgroundColor: $(".swiper-slide section .page").hasClass("infographic") ? "#434343" : "f4f3f5"
                    }), setTimeout(function() {
                        document.querySelector("main").classList.add("preview-iframe");
                        var e = i.opts.result.data.article.contents.design,
                            t = $(window).width(),
                            a = $(window).height();
                        (e.width / e.height >= t / a && !b() ? $("#transverse-full") : $("#portrait-full")).click()
                    }, 30), this.opts.page && (q.activeIndex = this.opts.page, $(".swiper-wrapper").css("transition-duration", "0s"), P(), setTimeout(function() {
                        this.opts.page = null, $(".swiper-wrapper").css("transition-duration", "0.3s")
                    }, 10)))
                }
            }, {
                key: "reloadBlocksInPages",
                value: function(e) {
                    var a = this;
                    e.forEach(function(e, t) {
                        a.resolveBlock(e.blocks, t, e)
                    })
                }
            }, {
                key: "setPageCss",
                value: function(e) {
                    var t = e.article.contents.pages[0].blocks;
                    if (this.opts.hideToolbar && "true" === this.opts.hideToolbar && (document.querySelector(".util-box").style.display = "none"), e.partner_logo ? (document.querySelector(".logo-href").href = "javascript:void(0)", document.querySelector(".head-logo").src = e.partner_logo, document.querySelector(".head-logo").style.visibility = "visible", document.querySelector("footer").style.display = "none", document.querySelector("main").style.minHeight = "100%", this.opts.partner_logo = e.partner_logo) : (pageConfig.usingLocalData || (document.querySelector(".head-logo").src = "./images/logo.svg"), document.querySelector(".head-logo").style.visibility = "visible", document.querySelector(".head-logo").addEventListener("click", function() {
                            window._hmt.push(["_trackEvent", "xshow", "top-logo", "navigation"])
                        })), v(location.href).id && "c" === v(location.href).id.split("_")[0] || pageConfig.isSingleChar) {
                        t[0].props.watermarkDisplay && t[0].props.watermarkDisplay.show && (document.querySelector(".block-container").style.background = "url(".concat(t[0].props.watermarkDisplay.imgUrl, ")"));
                        var a = t[0].props.logoDisplay && "32" === t[0].props.logoDisplay.imgHeight ? 24 : 16;
                        if (!t[0].props.logoDisplay) return;
                        e = ~~t[0].props.logoDisplay.imgHeight + ~~t[0].props.logoDisplay.topLineHeight + ~~t[0].props.logoDisplay.bottomLineHeight + "px";
                        t[0].props && t[0].props.publishDisplay && t[0].props.logoDisplay && (t[0].props.publishDisplay.show || t[0].props.logoDisplay.show) && ($(".logo").addClass("show"), $(".logo").css({
                            height: e,
                            padding: "0 " + a + "px"
                        })), t[0].props.publishDisplay.show && ($(".logo-text").addClass("show"), $(".logo-text").html(t[0].props.publishDisplay.text), $(".logo-text").css({
                            lineHeight: ~~t[0].props.logoDisplay.imgHeight + ~~t[0].props.logoDisplay.topLineHeight + ~~t[0].props.logoDisplay.bottomLineHeight - 5 + "px",
                            color: this.colorToRGBA(t[0].props.publishDisplay.color),
                            fontSize: t[0].props.publishDisplay.fontSize + "px",
                            fontFamily: t[0].props.publishDisplay.fontFamily
                        })), t[0].props.logoDisplay.show && ($(".logo-img").addClass("show"), $(".logo-img").attr("src", t[0].props.logoDisplay.imgUrl), $(".logo-img").css({
                            maxHeight: t[0].props.logoDisplay.imgHeight + "px",
                            marginTop: t[0].props.logoDisplay.topLineHeight + "px",
                            marginBottom: t[0].props.logoDisplay.bottomLineHeight + "px",
                            right: a + "px"
                        }))
                    }
                    a = v(location.href).id.includes("c_") ? "chart" : "project";
                    ("chart" == a && 88801 !== this.opts.payData.resultCode || "project" == a && 88801 !== this.opts.payData.resultCode && this.opts.payData.data.some(function(e) {
                        return "pt" === e.type
                    })) && $(".page").append('<i class="bg-watermark"></i>'), "true" === this.opts.hidewatermark && $(".bg-watermark").css("display", "none")
                }
            }, {
                key: "resolveDesign",
                value: function(i) {
                    var t, e, a, o, r = this,
                        s = i.design;
                    i.pages.forEach(function(e, t) {
                        var a = document.createElement("section"),
                            o = document.createElement("div"),
                            n = document.createElement("div");
                        n.className = "page-wrapper swiper-slide", o.className = "page", o.setAttribute("data-index", t), o.innerHTML = '\n      <div class="page-logo ">\n      '.concat((0 != t || !b()) && b() ? "" : '<img class="page-logo-img" src="./images/right-logo.svg" alt="">', '\n      <div class="logoHint ').concat(b() ? "none" : "", '">\n        <i></i>\n        <p>1.开通<a href="https://dycharts.com/appv2/#/pages/common/price?company=1"      target="_blank">企业会员</a>进行全屏预览可隐藏右上角logo</p>\n        <p>2.开通<a href="https://dycharts.com/appv2/#/pages/common/price?company=1"      target="_blank">企业旗舰版</a>去除或定制右上角logo</p>\n        </div>\n      </div>\n    </div>\n      <div class="logo">\n        <div class="inner-logo">\n          <div class="logo-text"><span style="opacity: 0;">镝</span></div>\n          <img class="logo-img" alt="logo">\n        </div>\n      </div>'), a.appendChild(o), n.appendChild(a), $(".content-wrapper").append(n), r.opts.pageList.push(o), r.opts.pageboxList.push(a), "infographic" === r.opts.pageType ? o.classList.add("infographic") : o.classList.add("chart"), $(o).css({
                            width: s.width,
                            height: s.height,
                            background: T((e.design && e.design.backgroundColor ? e.design : s).backgroundColor)
                        }), e.design && e.design.useImg && ($(o).append('<div class="bg-img-container">\n              <div class="bg-img"></div>\n            </div>'), $(".swiper-slide").eq(t).find(".bg-img").addClass(e.design.backgroundImage.fillingType), "crop" === e.design.backgroundImage.fillingType ? (o = i.design.width / e.design.backgroundImage.cropper.cropperWidth, $(".swiper-slide").eq(t).find(".bg-img").css({
                            display: "block",
                            "background-image": "url(".concat(e.design.backgroundImage.backgroundImgUrl, ")"),
                            opacity: "".concat(e.design.backgroundImage.opacity / 100, " "),
                            width: "".concat(e.design.backgroundImage.cropper.cropperWidthRatio * s.width, "px"),
                            height: "".concat(e.design.backgroundImage.cropper.cropperHeightRatio * s.height, "px"),
                            "background-position": "-".concat(e.design.backgroundImage.cropper.left * o, "px -").concat(e.design.backgroundImage.cropper.top * o, "px")
                        })) : $(".swiper-slide").eq(t).find(".bg-img").css({
                            display: "block",
                            background: "url(".concat(e.design.backgroundImage.backgroundImgUrl, ")"),
                            opacity: "".concat(e.design.backgroundImage.opacity / 100, " "),
                            width: "100%",
                            height: "100%"
                        }))
                    }), q = null, $(".swiper-button-prev").unbind(), $(".swiper-button-next").unbind(), q = new Swiper(".swiper-container", {
                        loop: !1,
                        resizeReInit: !0,
                        simulateTouch: !1,
                        onlyExternal: !0,
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev"
                        }
                    }), $(".swiper-button-prev").on("click", function(e) {
                        $(".swiper-slide").eq(parseInt(q.activeIndex)).find(".animation-button").hasClass("active") && $(".swiper-slide").eq(parseInt(q.activeIndex)).find(".animation-button").click(), --q.activeIndex, P(), H()
                    }.bind(this)), $(".swiper-button-next").on("click", function(e) {
                        $(".swiper-slide").eq(parseInt(q.activeIndex)).find(".animation-button").hasClass("active") && $(".swiper-slide").eq(parseInt(q.activeIndex)).find(".animation-button").click(), ++q.activeIndex, P(), H()
                    }.bind(this)), $(".swiper-button-prev").on("mouseover", function(e) {
                        this.opts.ishover = !0
                    }.bind(this)), $(".swiper-button-prev").on("mouseout", function(e) {
                        this.opts.ishover = !1
                    }.bind(this)), $(".swiper-button-next").on("mouseover", function(e) {
                        this.opts.ishover = !0
                    }.bind(this)), $(".swiper-button-next").on("mouseout", function(e) {
                        this.opts.ishover = !1
                    }.bind(this)), this.setLogoEvent(), !b() && window.self === window.top || (t = this, window.onresize = (e = function() {
                        t.updatePageSize(), t.reloadBlocksForPPT();
                        var e = !!(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement);
                        !self == top || e || clearInterval(t.opts.hideDomInterval)
                    }, a = 200, o = null, function() {
                        clearTimeout(o), o = setTimeout(function() {
                            e()
                        }, a)
                    }))
                }
            }, {
                key: "updatePageSize",
                value: function() {
                    function e() {
                        var e = !!(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement),
                            t = s.opts.result.data.article.contents.design,
                            a = 0,
                            o = 0,
                            n = $(window).width(),
                            i = ($(window).height(), null),
                            r = parseInt(v(location.href).height),
                            i = s.opts.type ? {
                                width: a = 544,
                                height: (o = a / t.width) * t.height
                            } : r ? {
                                width: (o = r / t.height) * t.width,
                                height: r
                            } : {
                                width: a = b() || e || self != top ? n : 1e3 < parseInt(t.width) && !b() ? 1e3 : parseInt(t.width) < 500 && !b() ? 500 : t.width,
                                height: (o = a / t.width) * t.height
                            };
                        s.opts.refresh_rate && !b() && (a = document.getElementById("scale-number").innerHTML, e && (a = document.getElementById("scale-number-full").innerHTML), i = {
                            width: (o = (a = Number(a.substring(0, a.length - 1))) / 100) * t.width,
                            height: o * t.height
                        }), s.opts.result.data.partner_miniwatermark && ($(".page-logo-img").attr("src", s.opts.result.data.partner_miniwatermark), $(".logoHint").addClass("none")), $(".page-logo-img").css("width", 115 / o + "px"), $(".logoHint ").css({
                            width: 293 / o + "px",
                            height: 64 / o + "px",
                            padding: 12 / o + "px " + 18 / o + "px",
                            right: 10 / o + "px",
                            top: 24 / o + "px"
                        }), $(".logoHint p").css({
                            "line-height": 20 / o + "px",
                            "font-size": 12 / o + "px"
                        }), $(".logoHint p a").css({
                            margin: "0 " + 2 / o + "px"
                        }), $(".swiper-slide .page").css("transform", "scale(" + o + ")"), $(".swiper-slide section").css(i), s.opts.pageScale = o, s.opts.scaleNum, document.getElementById("scale-number").innerHTML = Math.floor(100 * o) + "%", R(1), P()
                    }
                    var s = this;
                    e(), setTimeout(function() {
                        e()
                    }.bind(this), 30)
                }
            }, {
                key: "resolveBlock",
                value: function(s, l, d) {
                    for (var c = this, p = this, u = [], e = function(t) {
                            var e = Number(s[t].props.size.height),
                                a = Number(s[t].props.size.width);
                            if (!(!isNaN(e) && 0 < e && !isNaN(a) && 0 < a) || !Number(s[t].position.top) && 0 !== Number(s[t].position.top) || !Number(s[t].position.left) && 0 !== Number(s[t].position.left)) return "continue";
                            switch (s[t].position.left = Number(s[t].position.left), s[t].position.top = Number(s[t].position.top), s[t].type) {
                                case "image":
                                    void 0 === s[t].props.shadow.display && (o = _.cloneDeep(E), s[t].props.shadow.display = o.props.shadow.display), c.resolveImg(s[t], l);
                                    break;
                                case "chart":
                                    var o, n = s[t],
                                        i = [],
                                        r = null;
                                    n.dataSrc.remoteData ? (n.dataSrc.remoteData.map(function(e, t) {
                                        "dycharts" === e.sheetSrc && i.push({
                                            index: t,
                                            sheetId: e.sheetId,
                                            url: (e = e).teamId ? "".concat(m, "/vis/team/").concat(e.teamId, "/data/").concat(e.dataId, "/?source=xshow") : "".concat(m, "/datastore/v2/data/").concat(e.dataId, "/")
                                        })
                                    }), o = i.map(function(e) {
                                        return fetch(e.url).then(function(e) {
                                            return e.json()
                                        })
                                    }), Promise.all(o).then(function(a) {
                                        i.map(function(e, t) {
                                            n.dataSrc.data[e.index] = a[t].data ? a[t].data.data[e.sheetId] : [
                                                [""]
                                            ]
                                        }), r = p.resolveChart(n, l, t, d)
                                    })) : r = p.resolveChart(n, l, t, d), u.push(r);
                                    break;
                                case "text":
                                    c.resolveText(s[t], l);
                                    break;
                                case "shape":
                                    s[t].props.shadow || Object.keys(L).map(function(e) {
                                        L[e].shapeType === s[t].shapeType && (s[t].props.shadow = L[e].props.shadow)
                                    }), c.resolveShape(s[t], l);
                                    break;
                                case "audio":
                                    c.resolveSong(s[t], l);
                                    break;
                                case "video":
                                    c.resolveVideo(s[t], l);
                                    break;
                                case "group":
                                    c.resolveGroup(s[t], l, d)
                            }
                        }, t = 0; t < s.length; t++) e(t);
                    A[l] = u
                }
            }, {
                key: "resolveGroup",
                value: function(e, t, a) {
                    var d = this,
                        o = f(e),
                        n = f(o.props).children,
                        i = f(o.position),
                        r = i.left,
                        s = i.top,
                        e = f(o.props.size),
                        i = e.width,
                        o = e.height,
                        c = e.rotate,
                        p = this.getRectCenterPoint(i, o, Number(r), Number(s));
                    n.forEach(function(e, t) {
                        var a, o, n = f(e),
                            i = e.props.size,
                            r = i.width,
                            s = i.height,
                            l = e.position,
                            i = l.top,
                            l = l.left;
                        0 !== c && (i = (i = ((l = d.getRectCenterPoint(Number(r), Number(s), Number(l), Number(i))).y - p.y) / (l.x - p.x)) || 0, i = Math.atan(i) / Math.PI * 180, i = d.getRotateCenterPos(l, p, i + c), e.position.left = i.x - r / 2, e.position.top = i.y - s / 2, e.props.size.rotate = Number(e.props.size.rotate) + c), "group" === e.type && (a = Number(e.position.left) - Number(n.position.left), o = Number(e.position.top) - Number(n.position.top), e.props.children.map(function(e) {
                            e.position.left = Math.round(Number(e.position.left) + Number(a)), e.position.top = Math.round(Number(e.position.top) + Number(o))
                        }))
                    }), this.resolveBlock(n, t, a)
                }
            }, {
                key: "resolveImg",
                value: function(e, t) {
                    var a = this.opts.pageList[t],
                        o = document.createElement("img"),
                        t = e.props;
                    pageConfig.usingLocalData ? o.src = "./images/".concat(new URL(e.src).pathname.match("[^/]+(?!.*/)")[0]) : o.src = e.src, this.setCss(o, {
                        left: e.position.left,
                        top: e.position.top,
                        width: t.size.width,
                        height: t.size.height,
                        border: "".concat(t.border.strokeWidth, "px ").concat(t.border.strokeType, " ") + this.colorToRGBA(t.border.strokeColor),
                        borderRadius: t.borderRadius,
                        opacity: t.opacity,
                        rotate: t.size.rotate,
                        boxShadow: t.shadow && t.shadow.display ? "".concat(Math.round(t.shadow.shadowRadius * Math.cos(t.shadow.shadowAngle * Math.PI / 180)), "px\n                       ").concat(Math.round(t.shadow.shadowRadius * Math.sin(t.shadow.shadowAngle * Math.PI / 180)), "px\n                       ").concat(t.shadow.shadowBlur, "px\n                       ").concat(t.shadow.shadowBlur, "px\n                       ").concat(this.colorToRGBA(t.shadow.shadowColor)) : ""
                    }), a.appendChild(o)
                }
            }, {
                key: "resolveChart",
                value: function(t, e, a, o) {
                    t.props.mapPosition && 0 == t.props.mapPosition.canAdjust && $(".swiper-slide").eq(e).find(".logo").addClass("noshow");
                    var n = JSON.parse(JSON.stringify(t));
                    n.templateId = !(((i = n.templateId) + "").includes("8111111888800011") || (i + "").includes("8111111888800021") || (i + "").includes("8111111888800031") || (i + "").includes("8111111888800041") || (i + "").includes("8111111888800051")) ? n.templateId : n.templateId.substring(0, n.templateId.length - 3), n.props.animation && (n.props.animation.transition = !1), "cross" === n.templateSwitch && "7955555777700001207" !== (n = this.tbAfterChange(n)).templateId && "7955555777700001208" !== n.templateId && (n = this.finishColorListLength(n));
                    var i = this.opts.pageList[e],
                        e = document.createElement("div");
                    e.className = "block-container", e.setAttribute("data-index", a);
                    a = n.props;
                    a.size.width = Number(a.size.width) + 2, a.size.height = Number(a.size.height) + 2, this.setCss(e, {
                        left: n.position.left,
                        top: n.position.top,
                        width: a.size.width,
                        height: a.size.height,
                        rotate: a.size.rotate
                    }), i.appendChild(e);
                    i = v(location.href).id.includes("c_") ? "chart" : "project";
                    88801 !== this.opts.payData.resultCode && "project" == i && this.opts.payData.data.some(function(e) {
                        return e.id === t.templateId
                    }) && $(e).append('<i class="bg-watermark"></i>'), "8000000011111111001" !== n.templateId && "8000000011111111002" !== n.templateId && "8000000011111111003" !== n.templateId && "8000000011111111004" !== n.templateId && "7955555777700001602" !== n.templateId || (n.props.timerControl.frameDuration = "0" == n.props.timerControl.frameDuration || 0 == n.props.timerControl.frameDuration ? 1 : n.props.timerControl.frameDuration, v(location.href).times && (l = Number(v(location.href).times), n.props.timerControl.frameDuration = Number(n.props.timerControl.frameDuration) * l, n.props.timerControl.options && 3 === n.props.timerControl.options[0].length && (n.props.timerControl.options[0][2] = Number(n.props.timerControl.options[0][2]) * l)), v(location.href).startDelay && (r = Number(v(location.href).startDelay), n.props.animation.startDelay = r), b() ? (e.innerHTML += '<div class="mask" id="' + n.blockId + "_" + o.pageId + 'mask"></div>', e.innerHTML += '<div class="animation-button" id="' + n.blockId + "_" + o.pageId + '"></div>') : v(location.href).id ? e.innerHTML += '<div class="animation-button" id="' + n.blockId + "_" + o.pageId + '"></div>' : e.innerHTML += '<div class="animation-button is-local" id="' + n.blockId + "_" + o.pageId + '"></div>');
                    var r, s, l, i = function(e, t) {
                        switch (e) {
                            case "5544734748594536492":
                                return new window.d3Chart.RoundCornerDonutChart(t);
                            case "5544734748594536493":
                                return new window.d3Chart.RoundCornerPieChart(t);
                            case "5944734748594536331":
                                return new window.d3Chart.RoseChart(t);
                            case "5943734748594536331":
                                return new window.d3Chart.QuarterRoseChart(t);
                            case "5544734748594536499":
                                return new window.d3Chart.OverlapAreaChart(t);
                            case "5612096174443311134":
                                return new window.d3Chart.StepLineChart(t);
                            case "5945734748594536331":
                                return new window.d3Chart.RadialBarChart(t);
                            case "5948734748594536332":
                                return new window.d3Chart.RadialLineChart(t);
                            case "4447460703254610031":
                                return new window.d3Chart.WaveCircleChart(t);
                            case "5544734748594536473":
                                return new window.d3Chart.IconBarChart(t);
                            case "5543733748594536505":
                                return new window.d3Chart.SimpleSankeyChart(t);
                            case "5543733748594536504":
                                return new window.d3Chart.SankeyChart(t);
                            case "5543533748794536504":
                                return new window.d3Chart.VerticalSankeyChart(t);
                            case "4447460703254610041":
                                return new window.d3Chart.IconPieChart(t);
                            case "5544734748594536494":
                                return new window.d3Chart.TwoLevelDonutChart(t);
                            case "5544734748594536500":
                                return new window.d3Chart.ChordChart(t);
                            case "5544734748594536503":
                                return new window.d3Chart.OneLevelTreemapChart(t);
                            case "5544734748594536502":
                                return new window.d3Chart.TwoLevelTreemapChart(t);
                            case "5543734748594537504":
                                return new window.d3Chart.SunburstChart(t);
                            case "5543734748595436502":
                                return new window.d3Chart.TreeChart(t);
                            case "5543734748594536502":
                                return new window.d3Chart.WeightedTreeChart(t);
                            case "5544734748594536478":
                                return new window.d3Chart.MultipleBarChart(t);
                            case "5544734748594536487":
                                return new window.d3Chart.PyramidChart(t);
                            case "5544734748594536491":
                                return new window.d3Chart.RadarChart(t);
                            case "5544734748594536486":
                                return new window.d3Chart.StreamgraphChart(t);
                            case "4612096174443311107":
                                return new window.d3Chart.GroupingBubbleChart(t);
                            case "5544734748594536484":
                                return new window.d3Chart.CalendarHeatmapChart(t);
                            case "5612096174443311145":
                                return new window.d3Chart.HollowChart(t);
                            case "5544734748594536330":
                                return new window.d3Chart.ChangeWaterfallHistogramChart(t);
                            case "5544734748594536326":
                                return new window.d3Chart.FormWaterfallHistogramChart(t);
                            case "5544734748594536498":
                                return new window.d3Chart.StackedChart(t);
                            case "444746070325460997":
                                return new window.d3Chart.PieChart(t);
                            case "444746070325460998":
                                return new window.d3Chart.DonutChart(t);
                            case "444746070325460999":
                                return new window.d3Chart.DeformedPieChart(t);
                            case "4544734748594536433":
                                return new window.d3Chart.BeeLineChart(t);
                            case "5948734748594536789":
                                return new window.d3Chart.SmoothLineChart(t);
                            case "444734748594536323":
                                return new window.d3Chart.SimpleBarChart(t);
                            case "154772011302084304":
                                return new window.d3Chart.BasicHorizontalBarChart(t);
                            case "3612096174443311105":
                                return new window.d3Chart.GroupedBarChart(t);
                            case "3612096174443311107":
                                return new window.d3Chart.StackBarChart(t);
                            case "3612096174443311106":
                                return new window.d3Chart.NegativeHorizontalBarChart(t);
                            case "3612096174443311110":
                                return new window.d3Chart.GroupedHorizontalBarChart(t);
                            case "3612096174443311109":
                                return new window.d3Chart.StackHorizontalBarChart(t);
                            case "5544734748594536332":
                                return new window.d3Chart.MixLineBarChart(t);
                            case "4544734748594536434":
                                return new window.d3Chart.StackedLinearChart(t);
                            case "451905388296536065":
                                return new window.d3Chart.PolygonRadarChart(t);
                            case "5544734748594536339":
                                return new window.d3Chart.FunnelChart(t);
                            case "154778025133261039":
                                return new window.d3Chart.PercentageAreaChart(t);
                            case "154778102528502157":
                                return new window.d3Chart.PercentageBarChart(t);
                            case "154777746677828400":
                                return new window.d3Chart.HalfPieChart(t);
                            case "154778171740391769":
                                return new window.d3Chart.ProgressRoundPieChart(t);
                            case "154778145806026722":
                                return new window.d3Chart.BarProgressChart(t);
                            case "154777820323716078":
                                return new window.d3Chart.HalfProgressPieChart(t);
                            case "154771854328053247":
                                return new window.d3Chart.ArcDiagramChart(t);
                            case "154778232785223023":
                                return new window.d3Chart.SlopeChart(t);
                            case "154777693253141239":
                                return new window.d3Chart.GanttChart(t);
                            case "154778205305403383":
                                return new window.d3Chart.RankingChangeChart(t);
                            case "5544734748594536495":
                                return new window.d3Chart.SymmetricChart(t);
                            case "444746070325460995":
                                return new window.d3Chart.SimpleLineChart(t);
                            case "7612096173333355101":
                                return new window.d3Chart.ContrastiveFunnelChart(t);
                            case "7612096173333355103":
                                return new window.d3Chart.RelativeRadarChart(t);
                            case "7612096176663355107":
                            case "7612096176663355107":
                                return new window.d3Chart.StackCircleChart(t);
                            case "7612096176663355103":
                                return new window.d3Chart.RangeAreaChart(t);
                            case "7612096176663355104":
                                return new window.d3Chart.RangeBarChart(t);
                            case "7612096176663355105":
                                return new window.d3Chart.RangeHorizontalBarChart(t);
                            case "7612096174443355101":
                                return new window.d3Chart.PolarStackBarChart(t);
                            case "7612096174443355102":
                                return new window.d3Chart.PolarStackDonutBarChart(t);
                            case "7612096176663355106":
                                return new window.d3Chart.RoseDonutChart(t);
                            case "7612096173333355102":
                                return new window.d3Chart.HistogramChart(t);
                            case "114473474859453649":
                                return new window.d3Chart.WordCloudChart(t);
                            case "5544734748594536440":
                                return new window.d3Chart.RainfallVolumeLineChart(t);
                            case "5544734748594536441":
                                return new window.d3Chart.RainfallVolumeAreaChart(t);
                            case "111734748594536325":
                                return new window.d3Chart.DeformedBarChart(t);
                            case "3612096174443311122":
                                return new window.d3Chart.PunchBubbleChart(t);
                            case "3612096174443311121":
                                return new window.d3Chart.PolarBubbleChart(t);
                            case "3612096174443311123":
                                return new window.d3Chart.MultipleBubbleChart(t);
                            case "6543210123456536001":
                                return new window.d3Chart.BulletChart(t);
                            case "8000000011111111001":
                                return new window.d3Chart.DynamicBarChart(t);
                            case "8000000011111111002":
                                return new window.d3Chart.DynamicLineChart(t);
                            case "8000000011111111003":
                                return new window.d3Chart.DynamicRankLineChart(t);
                            case "8000000011111111004":
                                return new window.d3Chart.PackChart(t);
                            case "7955555555502345001":
                                return new window.d3Chart.HundredPercentBarChart(t);
                            case "7955555555502345002":
                                return new window.d3Chart.PictographBarChart(t);
                            case "7955555555502345003":
                                return new window.d3Chart.ReverseOverlapAreaChart(t);
                            case "7955555555502345004":
                                return new window.d3Chart.ReverseStackedAreaChart(t);
                            case "7955555555502345005":
                                return new window.d3Chart.ReverseLineChart(t);
                            case "7955555555502346001":
                                return new window.d3Chart.TableChart(t);
                            case "7955555555502346002":
                                return new window.d3Chart.BasicScatterChart(t);
                            case "7955555555502346003":
                                return new window.d3Chart.HistogramChart(t);
                            case "7955555666601234501":
                                return new window.d3Chart.HundredPercentIconBarChart(t);
                            case "7955555666601234502":
                                return new window.d3Chart.LollipopChart(t);
                            case "7955555666601234503":
                                return new window.d3Chart.GroupAggregationBubbleChart(t);
                            case "7955555666601234504":
                                return new window.d3Chart.ForceDiagramChart(t);
                            case "7955555666601234505":
                                return new window.d3Chart.PolarAreaChart(t);
                            case "7955555666601234506":
                                return new window.d3Chart.PolarLineChart(t);
                            case "7955555666601234507":
                                return new window.d3Chart.ForceDiagramArrowChart(t);
                            case "7955555666601234508":
                                return new window.d3Chart.VerticalDumbbellChart(t);
                            case "7955555777700001203":
                                return new window.d3Chart.ParallelLineChart(t);
                            case "7955555777700001204":
                                return new window.d3Chart.ButterflyChart(t);
                            case "7955555777700001202":
                                return new window.d3Chart.ReverseFunnelChart(t);
                            case "7955555777700001201":
                                return new window.d3Chart.SoapBubbleChart(t);
                            case "7955555777700001205":
                                return new window.d3Chart.PolarBarChart(t);
                            case "7955555777700001206":
                                return new window.d3Chart.PolarStackRectangularChart(t);
                            case "7955555777700001207":
                                return new window.d3Chart.DescartesHeatmapChart(t);
                            case "7955555777700001208":
                                return new window.d3Chart.PolarHeatmapChart(t);
                            case "7955555777700001209":
                                return new window.d3Chart.TernaryChart(t);
                            case "7955555777700001301":
                                return new window.d3Chart.MixLineStackBarChart(t);
                            case "7955555777700001302":
                                return new window.d3Chart.MixLineStackHorizontalBarChart(t);
                            case "7955555777700001303":
                                return new window.d3Chart.MixLineGroupHorizontalBarChart(t);
                            case "7955555777700001304":
                                return new window.d3Chart.MixLineOverlapAreaChart(t);
                            case "7955555777700001305":
                                return new window.d3Chart.PercentageStackIconBarChart(t);
                            case "7955555777700001306":
                                return new window.d3Chart.StackIconBarChart(t);
                            case "7955555777700001307":
                                return new window.d3Chart.StackRadialBarChart(t);
                            case "7955555777700001309":
                                return new window.d3Chart.ButterflyAreaChart(t);
                            case "7955555777700001501":
                                return new window.d3Chart.HorizontalDumbbellChart(t);
                            case "7955555777700001603":
                                return new window.d3Chart.BoxPlotChart(t);
                            case "7955555777700001601":
                                return new window.d3Chart.VerticalButterflyBarChart(t);
                            case "7955555777700001602":
                                return new window.d3Chart.DynamicVoronoiChart(t);
                            case "8111111888800011":
                                return new window.d3Chart.BasicMapChart(t);
                            case "8111111888800021":
                                return new window.d3Chart.PieAreaMapChart(t);
                            case "8111111888800031":
                                return new window.d3Chart.StackBarAreaMapChart(t);
                            case "8111111888800041":
                                return new window.d3Chart.BubbleAreaMapChart(t);
                            case "8111111888800051":
                                return new window.d3Chart.GroupBarAreaMapChart(t);
                            case "7955555777700001701":
                                return new window.d3Chart.DifferenceStackBarChart(t);
                            case "7955555777700001702":
                                return new window.d3Chart.DifferenceArrowHorizontalBarChart(t);
                            case "7955555777700001703":
                                return new window.d3Chart.DifferenceArrowBarChart(t);
                            case "7955555777700001704":
                                return new window.d3Chart.MarimekkoChart(t);
                            default:
                                return new window.d3Chart.PieChart(t)
                        }
                    }(n.templateId, e);
                    "8000000011111111001" !== n.templateId && "8000000011111111002" !== n.templateId && "8000000011111111003" !== n.templateId && "8000000011111111004" !== n.templateId && "7955555777700001602" !== n.templateId || (n.interval = "", n.isRun = !1, n.showPage = this, n.pageId = o.pageId, n.count = 0, n.startInterval = "", n.d3Chart = i, n.isShowButton = !0, l = 0, "8000000011111111004" === (r = n).templateId || "7955555777700001602" === r.templateId ? (s = void 0 !== (s = r.props.map[0][_.findIndex(r.props.map[0], function(e) {
                        return "timeCol" === e.function
                    })].index) ? s : 1, r.dynamicData = _.uniq(_.unzip(r.dataSrc.data[0])[s].slice(1))) : (s = void 0 !== (s = r.props.map[0][_.findIndex(r.props.map[0], function(e) {
                        return "timeColUni" === e.function
                    })].index) ? s : 1, r.dynamicData = _.unzip(r.dataSrc.data[0])[s].slice(1)), l = r.dynamicData.length, r.totaltime = (l - 1) * Number(r.props.timerControl.frameDuration) + Number(r.props.animation.startDelay) + Number(r.props.animation.endPause), b() ? (document.getElementById(n.blockId + "_" + o.pageId + "mask").addEventListener("click", this.handleButtonClickMoblie.bind(n)), document.getElementById(n.blockId + "_" + o.pageId).addEventListener("click", this.handleButtonMoblie.bind(n))) : (document.getElementById(n.blockId + "_" + o.pageId).addEventListener("click", this.handleButtonClick.bind(n)), e.addEventListener("mouseleave", function() {
                        n.isRun && (document.getElementById(n.blockId + "_" + o.pageId).style.display = "none")
                    }), e.addEventListener("mouseenter", function() {
                        document.getElementById(n.blockId + "_" + o.pageId).style.display = "block"
                    })));
                    try {
                        i.setOption(n)
                    } catch (e) {
                        console.log("d3Chart.setOption出错:"), console.log(e)
                    }
                    return ("Chrome" !== C() && "Safari" !== C() || v(location.href).isppt) && (i.tooltip.scale(Number(this.opts.scaleNumTotal)), i.setOption(n)), e.querySelector("svg") && (e.querySelector("svg").style.filter = a.shadow && a.shadow.display ? "drop-shadow(".concat(this.colorToRGBA(a.shadow.shadowColor), " \n                                                                      ").concat(Math.round(a.shadow.shadowRadius * Math.cos(a.shadow.shadowAngle * Math.PI / 180)), "px\n                                                                      ").concat(Math.round(a.shadow.shadowRadius * Math.sin(a.shadow.shadowAngle * Math.PI / 180)), "px \n                                                                      ").concat(a.shadow.shadowBlur, "px)") : ""), {
                        transition: t.props.animation ? t.props.animation.transition : null,
                        d3Chart: i
                    }
                }
            }, {
                key: "resolveText",
                value: function(e, t) {
                    var a = this.opts.pageList[t],
                        o = document.createElement("textarea"),
                        t = e.props;
                    "Chrome" !== C() && "Safari" !== C() || v(location.href).isppt ? o.innerHTML = t.content : (o.value = t.content, o.innerHTML = t.content.replace(/[\r\n]/g, "&#13;").replace(/\s/g, "&nbsp;")), o.readOnly = "readonly", o.className = "textarea", this.setCss(o, {
                        left: e.position.left,
                        top: e.position.top,
                        width: t.size.width,
                        height: t.size.height,
                        rotate: t.size.rotate,
                        opacity: t.opacity,
                        fontSize: t.fontSize,
                        fontFamily: t.fontFamily,
                        color: t.color,
                        letterSpacing: t.letterSpacing,
                        lineHeight: t.lineHeight,
                        textAlign: t.basic.align,
                        textDecoration: t.basic.underline ? "underline" : t.basic.deleteline ? "line-through" : "",
                        fontStyle: t.basic.italic ? "italic" : ""
                    }), a.appendChild(o)
                }
            }, {
                key: "resolveShape",
                value: function(e, t) {
                    "icon" === e.shapeType ? this.resolveIcon(e, t) : this.resolveDefaultShape(e, t)
                }
            }, {
                key: "resolveIcon",
                value: function(e, t) {
                    var a, o = this.opts.pageList[t],
                        n = document.createElement("div"),
                        i = e.props;
                    n.className = "shape-box", n.innerHTML = e.src;
                    t = -1 < i.fill.fillColor[0].indexOf("angle");
                    t ? (a = this.setGradient(i.fill.fillColor[0]), n.innerHTML += '<svg width="100%" height="100%" style="position:absolute;">\n        '.concat(this.getLinearGradientHtml(a, e), "\n      </svg>")) : a = {
                        colorList: [],
                        position: {
                            x1: 0,
                            x2: 0,
                            y1: 0,
                            y2: 0
                        }
                    }, this.setCss(n, {
                        left: e.position.left,
                        top: e.position.top,
                        width: i.size.width,
                        height: i.size.height,
                        rotate: i.size.rotate,
                        filter: i.shadow && i.shadow.display ? "drop-shadow(".concat(this.colorToRGBA(i.shadow.shadowColor), " \n                                            ").concat(Math.round(i.shadow.shadowRadius * Math.cos(i.shadow.shadowAngle * Math.PI / 180)), "px\n                                            ").concat(Math.round(i.shadow.shadowRadius * Math.sin(i.shadow.shadowAngle * Math.PI / 180)), "px \n                                            ").concat(i.shadow.shadowBlur, "px)") : ""
                    }), o.appendChild(n), i.tooltip && (n.addEventListener("mousemove", function(e) {
                        document.getElementById("tooltip").style.left = e.clientX + 10 + "px", document.getElementById("tooltip").style.top = e.clientY + 10 + "px", document.getElementById("tooltip").style.display = "block", document.getElementById("tooltip").innerHTML = i.tooltipText
                    }), n.addEventListener("mouseout", function(e) {
                        document.getElementById("tooltip").style.display = "none"
                    }));
                    n = n.querySelector("svg");
                    this.setSvgStyle(n, {
                        opacity: i.opacity / 100,
                        fill: t ? "url(#".concat(e.blockId, ")") : this.colorToRGBA(i.fill.fillColor[0]),
                        rx: i.specified ? i.specified.rx : 0,
                        ry: i.specified ? i.specified.ry : 0,
                        x: i.specified ? i.specified.x : 0,
                        y: i.specified ? i.specified.y : 0,
                        cx: i.specified ? i.specified.cx : 0,
                        cy: i.specified ? i.specified.cy : 0,
                        r: i.specified ? i.specified.r : 0,
                        x1: i.specified ? i.specified.x1 : 0,
                        y1: i.specified ? i.specified.y1 : 0,
                        x2: i.specified ? i.specified.x2 : 0,
                        y2: i.specified ? i.specified.y2 : 0,
                        stroke: "transparent" === i.strokeColor ? "transparent" : this.colorToRGBA(i.strokeColor),
                        "stroke-width": i.strokeWidth,
                        "stroke-dasharray": "0, 0" === i.strokeDasharray ? "0" : i.strokeDasharray
                    })
                }
            }, {
                key: "resolveDefaultShape",
                value: function(e, t) {
                    var a = this.opts.pageList[t],
                        o = document.createElement("div"),
                        n = e.props;
                    o.className = "shape-box";
                    var i = -1 < n.fill.fillColor[0].indexOf("angle"),
                        t = (i = "line" === e.shapeType ? -1 < n.strokeColor.indexOf("angle") : i) ? "line" === e.shapeType ? this.setGradient(n.strokeColor) : this.setGradient(n.fill.fillColor[0]) : {
                            colorList: [],
                            position: {
                                x1: 0,
                                x2: 0,
                                y1: 0,
                                y2: 0
                            }
                        };
                    this.setCss(o, {
                        left: e.position.left,
                        top: e.position.top,
                        width: n.size.width,
                        height: n.size.height,
                        rotate: n.size.rotate,
                        filter: n.shadow && n.shadow.display ? "drop-shadow(".concat(this.colorToRGBA(n.shadow.shadowColor), " \n                                            ").concat(Math.round(n.shadow.shadowRadius * Math.cos(n.shadow.shadowAngle * Math.PI / 180)), "px\n                                            ").concat(Math.round(n.shadow.shadowRadius * Math.sin(n.shadow.shadowAngle * Math.PI / 180)), "px \n                                            ").concat(n.shadow.shadowBlur, "px)") : ""
                    });
                    var r = {
                        width: n.size.width + "px",
                        height: n.size.height + "px",
                        opacity: n.opacity / 100,
                        fill: i ? "url(#".concat(e.blockId, ")") : this.colorToRGBA(n.fill.fillColor[0]),
                        rx: n.specified ? n.specified.rx : 0,
                        ry: n.specified ? n.specified.ry : 0,
                        x: n.specified ? n.specified.x : 0,
                        y: n.specified ? n.specified.y : 0,
                        cx: n.specified ? n.specified.cx : 0,
                        cy: n.specified ? n.specified.cy : 0,
                        r: n.specified ? n.specified.r : 0,
                        x1: n.specified ? n.specified.x1 : 0,
                        y1: n.specified ? n.specified.y1 : 0,
                        x2: n.specified ? n.specified.x2 : 0,
                        y2: n.specified ? n.specified.y2 : 0,
                        stroke: this.colorToRGBA(n.strokeColor),
                        strokeWidth: n.strokeWidth,
                        strokeDasharray: "0, 0" === n.strokeDasharray ? "0" : n.strokeDasharray,
                        linearGradient: t,
                        colorList: t ? t.colorList : []
                    };
                    switch (i && "line" === e.shapeType && (r.y2 = n.specified ? Number(n.specified.y2) + .1 : .1), e.shapeType) {
                        case "rectangle":
                        case "round-rectangle":
                            o.innerHTML = '\n          <svg width="100%" height="100%" preserveAspectRatio="none" stroke-miterlimit="60" version="1.1" xmlns="http://www.w3.org/2000/svg">\n            '.concat(this.getLinearGradientHtml(r.linearGradient, e), '\n            <rect class="svg-element"\n              width="').concat(r.width, '" height="').concat(r.height, '" opacity="').concat(r.opacity, '"\n              fill="').concat(r.fill, '" rx="').concat(r.rx, '" ry="').concat(r.ry, '" x="').concat(r.x, '"\n              y="').concat(r.y, '" stroke="').concat(r.stroke, '" stroke-width="').concat(r.strokeWidth, '"\n              stroke-dasharray="').concat(r.strokeDasharray, '"></rect>\n          </svg>\n        ');
                            break;
                        case "line":
                            o.innerHTML = '\n          <svg width="100%" height="100%" class="line-wrap" style="stroke: '.concat(r.fill, ';">\n            ').concat(this.getLinearGradientHtml(r.linearGradient, e), '\n            <line class="line" width="').concat(r.width, '"\n              height="').concat(r.height, '" opacity="').concat(r.opacity, '" fill="').concat(r.fill, '"\n              x1="').concat(r.x1, '" y1="').concat(r.y1, '" x2="').concat(r.x2, '" y2="').concat(r.y2, '"\n              stroke="').concat(r.stroke, '" stroke-width="').concat(r.strokeWidth, '" stroke-dasharray="').concat(r.strokeDasharray, '"\n              marker-start="').concat(r.markerStart, '" marker-end="').concat(r.markerEnd, '"></line>\n          </svg>\n        ');
                            break;
                        case "oval":
                            o.innerHTML = '\n          <svg width="100%" height="100%" preserveAspectRatio="none" stroke-miterlimit="60" version="1.1" xmlns="http://www.w3.org/2000/svg">\n            '.concat(this.getLinearGradientHtml(r.linearGradient, e), '\n            <ellipse class="svg-element" \n              opacity="').concat(r.opacity, '" fill="').concat(r.fill, '" cx="').concat(r.cx, '" cy="').concat(r.cy, '"\n              rx="').concat(r.rx, '" ry="').concat(r.ry, '" stroke="').concat(r.stroke, '" stroke-width="').concat(r.strokeWidth, '"\n              stroke-dasharray="').concat(r.strokeDasharray, '"></ellipse>\n          </svg>\n        ');
                            break;
                        case "triangle":
                            o.innerHTML = '\n        <svg width="100%" height="100%" preserveAspectRatio="none" stroke-miterlimit="60" version="1.1" xmlns="http://www.w3.org/2000/svg">\n          '.concat(this.getLinearGradientHtml(r.linearGradient, e), '\n          <polygon class="svg-element" \n            points="').concat(e.path, '" width="').concat(r.width, '" height="').concat(r.height, '" opacity="').concat(r.opacity, '" fill="').concat(r.fill, '" stroke="').concat(r.stroke, '" stroke-width="').concat(r.strokeWidth, '" stroke-dasharray="').concat(r.strokeDasharray, '"></polygon>\n        </svg>\n        ');
                            break;
                        case "pentagon":
                            o.innerHTML = '\n        <svg width="100%" height="100%" preserveAspectRatio="none" stroke-miterlimit="60" version="1.1" xmlns="http://www.w3.org/2000/svg">\n          '.concat(this.getLinearGradientHtml(r.linearGradient, e), '\n          <polygon class="svg-element" points="').concat(e.path, '"\n            width="').concat(r.width, '" height="').concat(r.height, '" opacity="').concat(r.opacity, '"\n            fill="').concat(r.fill, '" stroke="').concat(r.stroke, '" stroke-width="').concat(r.strokeWidth, '"\n            stroke-dasharray="').concat(r.strokeDasharray, '"></polygon>\n        </svg>\n        ')
                    }
                    a.appendChild(o), n.tooltip && (o.addEventListener("mousemove", function(e) {
                        document.getElementById("tooltip").style.left = e.clientX + 10 + "px", document.getElementById("tooltip").style.top = e.clientY + 10 + "px", document.getElementById("tooltip").style.display = "block", document.getElementById("tooltip").innerHTML = n.tooltipText
                    }), o.addEventListener("mouseout", function(e) {
                        document.getElementById("tooltip").style.display = "none"
                    }))
                }
            }, {
                key: "resolveSong",
                value: function(e, t) {
                    var a, o, n = this,
                        i = e.props,
                        r = e.blockId;
                    "bgm" === i.type ? (a = this.opts.pageList[t], (o = document.createElement("div")).className = "bgm-box", o.id = r, this.setCss(o, {
                        left: e.position.left,
                        top: e.position.top,
                        width: i.size.width,
                        height: i.size.height,
                        rotate: i.size.rotate,
                        opacity: i.opacity
                    }), a.appendChild(o), o.style.background = "url('./icons/bgm.svg') no-repeat", o.innerHTML = '<audio class="bgm-audio play-btn" src='.concat(e.props.data.src, "></audio>"), n.opts.dataClass[r] = S(), n.opts.dataClass[r].endTime = i.data.time, n.opts.dataClass[r].loopback = i.playControl.loopback, n.opts.dataClass[r].autoplay = i.playControl.autoplay, n.opts.dataClass[r].loopback && (document.getElementById(r).querySelector("audio").loop = "loop"), n.opts.dataClass[r].autoplay && n.opts.autoplayList.push(r), document.getElementById(r).querySelector("audio").addEventListener("timeupdate", function(e) {
                        e.target.currentTime >= u(n.opts.dataClass[r].endTime) && (n.opts.dataClass[r].loopback || ($(".bgm-audio")[0].currentTime = 0, $(".bgm-audio")[0].pause(), $(".bgm-box").removeClass("run")))
                    }), o.addEventListener("click", function() {
                        $(this).hasClass("run") ? (document.getElementById(r).querySelector("iframe") && document.getElementById(r).querySelector("iframe").remove(), $(".bgm-box").removeClass("run"), $(".bgm-audio")[0].pause()) : $(".bgm-audio")[0].play().then(function() {
                            $(".bgm-box").addClass("run")
                        }).catch(function(e) {
                            $(".m-shade").addClass("active")
                        }).finally(function() {})
                    })) : "insertSong" === i.type && (o = $(".page")[t], (t = document.createElement("div")).className = "song-box", t.id = r, this.setCss(t, {
                        left: e.position.left,
                        top: e.position.top,
                        width: i.size.width,
                        height: i.size.height,
                        rotate: i.size.rotate,
                        opacity: i.opacity
                    }), o.appendChild(t), o = {
                        "霜荼白": "white",
                        "深空灰": "gray",
                        "玄潭黑": "black",
                        "青泽绿": "green",
                        "哈尼粉": "pink",
                        "经典蓝": "blue"
                    }[i.skinSelected], t.innerHTML = '\n      <div class="audio-wrapper '.concat(o, '">\n        <p>').concat(i.data.title, '</p>\n        <div class="play-btn"></div>\n        <div class="slider-container ">\n          <div class="progress-wrap">\n            <input\n              type="range"\n              class="progress"\n              value = "0"\n            />\n          </div>\n        </div>    \n        <div class="wrapper">\n          <div class="start">00:00</div>\n          <div class="end">').concat(i.data.time, "</div>\n        </div>\n        <audio  src=").concat(e.props.data.src, "></audio>\n      </div>"), document.getElementById(r).querySelector(".play-btn").style.height = Number(i.size.height) / 186 * 70 + "px", document.getElementById(r).querySelector(".play-btn").style.width = Number(i.size.height) / 186 * 70 + "px", document.getElementById(r).querySelector("p").style.fontSize = Number(i.size.height) / 186 * 30 + "px", document.getElementById(r).querySelector(".wrapper").style.fontSize = Number(i.size.height) / 186 * 20 + "px", n.opts.dataClass[r] = S(), n.opts.dataClass[r].endTime = i.data.time, n.opts.dataClass[r].loopback = i.playControl.loopback, n.opts.dataClass[r].autoplay = i.playControl.autoplay, n.opts.dataClass[r].loopback && (document.getElementById(r).querySelector("audio").loop = "loop"), n.opts.dataClass[r].autoplay && n.opts.autoplayList.push(r), document.getElementById(r).querySelector(".play-btn").addEventListener("click", function() {
                        n.opts.dataClass[r].playing = !n.opts.dataClass[r].playing, n.opts.dataClass[r].playing ? (document.getElementById(r).querySelector("audio").play(), document.getElementById(r).querySelector(".play-btn").classList.add("active")) : (document.getElementById(r).querySelector("iframe") && document.getElementById(r).querySelector("iframe").remove(), document.getElementById(r).querySelector("audio").pause(), document.getElementById(r).querySelector(".play-btn").classList.remove("active"))
                    }), document.getElementById(r).querySelector("audio").addEventListener("timeupdate", function(e) {
                        document.getElementById(r).querySelector(".start").innerHTML = I(e.target.currentTime);
                        var t = e.target.currentTime / u(n.opts.dataClass[r].endTime) * 100;
                        document.getElementById(r).querySelector(".progress").value = t, document.getElementById(r).querySelector(".progress").style.backgroundSize = t + "% 100%", e.target.currentTime >= u(n.opts.dataClass[r].endTime) && (n.opts.dataClass[r].loopback ? (n.opts.dataClass[r].playing = !0, document.getElementById(r).querySelector(".progress").value = 0, document.getElementById(r).querySelector(".progress").style.backgroundSize = 0) : (n.opts.dataClass[r].playing = !1, document.getElementById(r).querySelector(".progress").style.backgroundSize = 0, document.getElementById(r).querySelector("audio").currentTime = 0, document.getElementById(r).querySelector("audio").pause(), document.getElementById(r).querySelector(".play-btn").classList.remove("active")))
                    }), document.getElementById(r).querySelector(".progress").addEventListener("input", function(e) {
                        document.getElementById(r).querySelector(".progress").style.backgroundSize = e.target.value + "% 100%", document.getElementById(r).querySelector("audio").currentTime = u(n.opts.dataClass[r].endTime) * e.target.value / 100, document.getElementById(r).querySelector(".start").innerHTML = I(document.getElementById(r).querySelector("audio").currentTime)
                    }))
                }
            }, {
                key: "resolveVideo",
                value: function(e, t) {
                    var a = e.props,
                        o = (e.blockId, this.opts.pageList[t]),
                        t = document.createElement("div");
                    t.className = "video-box", this.setCss(t, {
                        left: e.position.left,
                        top: e.position.top,
                        width: a.size.width,
                        height: a.size.height,
                        rotate: a.size.rotate,
                        opacity: a.opacity
                    }), o.appendChild(t), -1 < a.data.src.indexOf("<iframe") ? t.innerHTML = e.props.data.src : t.innerHTML = '<video\n                            controls="controls"\n                            src='.concat(e.props.data.src, "\n                          ></video>")
                }
            }, {
                key: "setCss",
                value: function(e, t) {
                    this.setStyle(e, (i(e = {
                        width: t.width ? t.width + "px" : null,
                        height: t.height ? t.height + "px" : null,
                        left: void 0 !== t.left ? t.left + "px" : null,
                        top: void 0 !== t.top ? t.top + "px" : null,
                        background: t.background || null,
                        backgroundColor: t.backgroundColor ? this.colorToRGBA(t.backgroundColor) : null,
                        border: t.border || null,
                        borderRadius: void 0 !== t.borderRadius ? t.borderRadius + "px" : null,
                        opacity: void 0 !== t.opacity ? t.opacity / 100 : null,
                        transform: void 0 !== t.rotate ? "rotate(" + t.rotate + "deg)" : null,
                        fontSize: t.fontSize ? t.fontSize + "px" : null,
                        fontFamily: t.fontFamily || null,
                        color: t.color ? this.colorToRGBA(t.color) : null,
                        letterSpacing: void 0 !== t.letterSpacing ? t.letterSpacing + "px" : null,
                        lineHeight: t.lineHeight || null,
                        textAlign: t.textAlign || null,
                        fontWeight: t.fontWeight ? "bold" : null
                    }, "textAlign", t.textAlign), i(e, "fontStyle", t.fontStyle), i(e, "textDecoration", t.textDecoration), i(e, "boxShadow", t.boxShadow), i(e, "filter", t.filter), e))
                }
            }, {
                key: "setStyle",
                value: function(e, t) {
                    for (var a in t) e.style[a] = t[a]
                }
            }, {
                key: "setSvgStyle",
                value: function(e, t) {
                    for (var a in t) e.setAttribute(a, t[a])
                }
            }, {
                key: "getRectCenterPoint",
                value: function(e, t, a, o) {
                    return {
                        x: e / 2 + a,
                        y: t / 2 + o
                    }
                }
            }, {
                key: "getRotateCenterPos",
                value: function(e, t, a) {
                    var o = e.x - t.x,
                        e = e.y - t.y,
                        e = Math.sqrt(Math.pow(o, 2) + Math.pow(e, 2)),
                        o = o < 0 ? -1 : 1;
                    return {
                        x: t.x + o * e * Math.cos(a * Math.PI / 180),
                        y: t.y + o * e * Math.sin(a * Math.PI / 180)
                    }
                }
            }, {
                key: "setGradient",
                value: function(e) {
                    var a = this,
                        t = JSON.parse(e.replace(RegExp("'", "g"), '"')),
                        o = [],
                        n = {},
                        e = {};
                    return t.map(function(e) {
                        var t;
                        e.indexOf("angle") < 0 ? ((t = {}).color = a.colorToRGBA(e.split(":")[0]), t.offset = e.split(":")[1], o.push(t)) : (t = Number(e.split(":")[1]), e = Math.round(1e4 * Math.sin((90 - t) / 180 * Math.PI)) / 100, t = Math.round(1e4 * Math.cos((90 - t) / 180 * Math.PI)) / 100, 0 <= e && 0 <= t && (n.x1 = "0%", n.y1 = "0%", n.x2 = "".concat(e, "%"), n.y2 = "".concat(t, "%")), 0 <= e && t <= 0 && (n.x1 = "0%", n.y1 = "".concat(-t, "%"), n.x2 = "".concat(e, "%"), n.y2 = "0%"), e <= 0 && t <= 0 && (n.x1 = "".concat(-e, "%"), n.y1 = "".concat(-t, "%"), n.x2 = "0%", n.y2 = "0%"), e <= 0 && 0 <= t && (n.x1 = "".concat(-e, "%"), n.y1 = "0%", n.x2 = "0%", n.y2 = "".concat(t, "%")))
                    }), e.colorList = o, e.position = n, e
                }
            }, {
                key: "getLinearGradientHtml",
                value: function(e, t) {
                    if (e) {
                        var t = '<defs>\n                      <linearGradient id="'.concat(t.blockId, '" \n                          x1="').concat(e.position.x1, '"\n                          y1="').concat(e.position.y1, '"\n                          x2="').concat(e.position.x2, '"\n                          y2="').concat(e.position.y2, '"\n                      >'),
                            a = "";
                        return e.colorList.map(function(e) {
                            a += '<stop offset="'.concat(e.offset, '" stop-color="').concat(e.color, '"/>')
                        }), t + a + "</linearGradient></defs>"
                    }
                    return ""
                }
            }, {
                key: "resolveDataStoreArticle",
                value: function(e, t) {
                    if (e) {
                        var d = {
                                _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                                encode: function(e) {
                                    var t, a, o, n, i, r, s = "",
                                        l = 0;
                                    for (e = d._utf8_encode(e); l < e.length;) o = (r = e.charCodeAt(l++)) >> 2, n = (3 & r) << 4 | (t = e.charCodeAt(l++)) >> 4, i = (15 & t) << 2 | (a = e.charCodeAt(l++)) >> 6, r = 63 & a, isNaN(t) ? i = r = 64 : isNaN(a) && (r = 64), s = s + this._keyStr.charAt(o) + this._keyStr.charAt(n) + this._keyStr.charAt(i) + this._keyStr.charAt(r);
                                    return s
                                },
                                decode: function(e) {
                                    var t, a, o, n, i, r, s = "",
                                        l = 0;
                                    for (e = e.replace(/[^A-Za-z0-9\+\/\=]/g, ""); l < e.length;) o = this._keyStr.indexOf(e.charAt(l++)), t = (15 & (n = this._keyStr.indexOf(e.charAt(l++)))) << 4 | (i = this._keyStr.indexOf(e.charAt(l++))) >> 2, a = (3 & i) << 6 | (r = this._keyStr.indexOf(e.charAt(l++))), s += String.fromCharCode(o << 2 | n >> 4), 64 != i && (s += String.fromCharCode(t)), 64 != r && (s += String.fromCharCode(a));
                                    return s = d._utf8_decode(s)
                                },
                                _utf8_encode: function(e) {
                                    e = e.replace(/\r\n/g, "\n");
                                    for (var t = "", a = 0; a < e.length; a++) {
                                        var o = e.charCodeAt(a);
                                        o < 128 ? t += String.fromCharCode(o) : (127 < o && o < 2048 ? t += String.fromCharCode(o >> 6 | 192) : (t += String.fromCharCode(o >> 12 | 224), t += String.fromCharCode(o >> 6 & 63 | 128)), t += String.fromCharCode(63 & o | 128))
                                    }
                                    return t
                                },
                                _utf8_decode: function(e) {
                                    for (var t, a, o = "", n = 0, i = 0; n < e.length;)(t = e.charCodeAt(n)) < 128 ? (o += String.fromCharCode(t), n++) : 191 < t && t < 224 ? (i = e.charCodeAt(n + 1), o += String.fromCharCode((31 & t) << 6 | 63 & i), n += 2) : (i = e.charCodeAt(n + 1), a = e.charCodeAt(n + 2), o += String.fromCharCode((15 & t) << 12 | (63 & i) << 6 | 63 & a), n += 3);
                                    return o
                                }
                            },
                            a = f(t),
                            e = t.article.contents.pages[0].blocks[0],
                            t = f(e.dataSrc.data[0]),
                            o = [];
                        t.map(function(e) {
                            e = e.map(function(e, t, a) {
                                if (!isNaN(e)) return e - 3;
                                if (/^b/.test(e)) try {
                                    return d.decode(e.substring(1))
                                } catch (e) {
                                    console.log(e)
                                }
                            });
                            o.push(e)
                        });
                        for (var n = 6 < o.length ? o.slice(0, 6) : o, i = 0; i < n.length; i++) 6 < n[i].length && (n[i] = n[i].slice(0, 6));
                        e.dataSrc.data[0] = n.map(function(e) {
                            return e.map(function(e) {
                                if ("" !== e) return isNaN(e) || e === parseInt(e) ? e : Math.ceil(1e4 * Number(e)) / 1e4
                            })
                        }), a.article.contents.pages[0].blocks[0] = f(e), "true" === this.opts.hidelegend && (a.article.contents.pages[0].blocks[0].props.legend.show = !1), this.resolveArticle(a)
                    }
                }
            }, {
                key: "resolveIframePage",
                value: function() {
                    this.opts.preview || document.querySelector("main").classList.add("iframe-main"), document.querySelector("footer").classList.add("iframe-footer"), document.querySelector("header").style.display = "none"
                }
            }, {
                key: "colorToRGBA",
                value: function(e) {
                    var t, a, o, n;
                    if ("string" == typeof(e = "" + e)) return "#" !== e.charAt(0) ? e : (8 === (e = 3 === (e = e.substring(n = 1)).length ? e[0] + e[0] + e[1] + e[1] + e[2] + e[2] : e).length && (n = Math.round(parseInt(e[6] + e[7], 16) / 255 * 100) / 100, e = e.substring(0, 6)), /^[0-9a-fA-F]{6}$/.test(e) && (t = parseInt(e.substr(0, 2), 16), a = parseInt(e.substr(2, 2), 16), o = parseInt(e.substr(4, 2), 16)), "rgba(" + t + "," + a + "," + o + "," + n + ")")
                }
            }, {
                key: "handleButtonClick",
                value: function() {
                    var e = $("#" + this.blockId + "_" + this.pageId).parents(".page").attr("data-index"),
                        t = $("#" + this.blockId + "_" + this.pageId).parents(".block-container").attr("data-index"),
                        t = D.opts.result.data.article.contents.pages[e].blocks[t];
                    this.isRun ? clearInterval(this.interval) : this.showPage.setTime(this), this.isRun = !this.isRun, this.isRun ? document.getElementById(this.blockId + "_" + this.pageId).classList.add("active") : document.getElementById(this.blockId + "_" + this.pageId).classList.remove("active"), this.showPage.dynamicDataRun(this.isRun, this, t)
                }
            }, {
                key: "handleButtonMoblie",
                value: function() {
                    var e = $("#" + this.blockId + "_" + this.pageId).parents(".page").attr("data-index"),
                        t = $("#" + this.blockId + "_" + this.pageId).parents(".block-container").attr("data-index"),
                        t = D.opts.result.data.article.contents.pages[e].blocks[t];
                    this.isRun ? (clearInterval(this.interval), this.showPage.isShowButton = !0) : (this.showPage.setTime(this), this.isShowButton = !1), this.isRun = !this.isRun, this.isShowButton ? document.getElementById(this.blockId + "_" + this.pageId).style.display = "block" : document.getElementById(this.blockId + "_" + this.pageId).style.display = "none", this.isRun ? document.getElementById(this.blockId + "_" + this.pageId).classList.add("active") : document.getElementById(this.blockId + "_" + this.pageId).classList.remove("active"), this.showPage.dynamicDataRun(this.isRun, this, t)
                }
            }, {
                key: "handleButtonClickMoblie",
                value: function() {
                    var e = $("#" + this.blockId + "_" + this.pageId).parents(".page").attr("data-index"),
                        t = $("#" + this.blockId + "_" + this.pageId).parents(".block-container").attr("data-index"),
                        t = D.opts.result.data.article.contents.pages[e].blocks[t];
                    0 === this.count ? (this.isRun = !0, document.getElementById(this.blockId + "_" + this.pageId).classList.add("active"), this.showPage.setTime(this), this.showPage.dynamicDataRun(this.isRun, this, t), this.isShowButton = !1, document.getElementById(this.blockId + "_" + this.pageId).style.display = "none") : this.count < this.totaltime && (this.isShowButton = !this.isShowButton, this.isShowButton ? document.getElementById(this.blockId + "_" + this.pageId).style.display = "block" : document.getElementById(this.blockId + "_" + this.pageId).style.display = "none")
                }
            }, {
                key: "setTime",
                value: function(e) {
                    clearInterval(e.showPage.interval), e.interval = setInterval(function() {
                        e.count += Number(e.props.timerControl.frameDuration), e.count > e.totaltime && (e.count = 0, e.isRun = !1, document.getElementById(e.blockId + "_" + e.pageId).classList.remove("active"), document.getElementById(e.blockId + "_" + e.pageId).style.display = "block", c(1, e), clearInterval(e.interval))
                    }, 1e3 * Number(e.props.timerControl.frameDuration))
                }
            }, {
                key: "dynamicDataRun",
                value: function(e, t, a) {
                    t.count <= t.props.animation.startDelay ? (clearInterval(t.startInterval), t.startInterval = setTimeout(function() {
                        c(e, t, a)
                    }, 1e3 * (Number(t.props.animation.startDelay) - Number(t.count)))) : c(e, t, a)
                }
            }, {
                key: "reloadBlocksForPPT",
                value: function() {
                    ("Chrome" !== C() && "Safari" !== C() || v(location.href).isppt) && this.reloadBlocks()
                }
            }, {
                key: "reloadBlocks",
                value: function() {}
            }, {
                key: "setIsscroll",
                value: function() {
                    this.opts.sectionHeight = $(".swiper-slide-active section")[0].getBoundingClientRect().height, this.opts.sectionWidth = $(".swiper-slide-active section")[0].getBoundingClientRect().width;
                    var e = ((document.body.clientWidth - 24) / 700).toFixed(2);
                    $(".swiper-slide-active section")[0].getBoundingClientRect().height * e + 24 > document.body.clientHeight && (this.opts.isScroll = !0)
                }
            }, {
                key: "addEventWX",
                value: function(t) {
                    var i = this;
                    b() && (this.opts.autoplayList.forEach(function(e) {
                        document.getElementById(e).querySelector(".play-btn").click()
                    }), setTimeout(function() {
                        var e = Math.floor(3 * Math.random()),
                            a = location.href.split("#")[0]; - 1 < a.indexOf("&from") && (a = a.split("&from")[0], window.location.href = a);
                        var o = t.share_image || ["https://ss1.dydata.io/v2/charts/dywchat_linechart.png", "https://ss1.dydata.io/v2/charts/dywchat_piechart.png", "https://ss1.dydata.io/v2/charts/dywchat_barchart.png"][e],
                            n = $(".project-description").html();
                        $.ajax({
                            url: "https://dycharts.com/vis/share/wechat/jsshare?url=" + a,
                            type: "GET",
                            async: !0,
                            cache: !1,
                            dataType: "json",
                            success: function(e) {
                                var t = {
                                    title: void 0,
                                    descText: n,
                                    link: a,
                                    imgUrl: o
                                };
                                wx.config({
                                    debug: !1,
                                    appId: "wxc319582657d38760",
                                    timestamp: e.data.timestamp,
                                    nonceStr: e.data.nonceStr,
                                    signature: e.data.signature,
                                    jsApiList: ["checkJsApi", "chooseWXPay", "updateAppMessageShareData", "updateTimelineShareData", "onMenuShareAppMessage", "onMenuShareTimeline", "onMenuShareWechat"],
                                    success: function(e) {
                                        this.setWxConfig(t)
                                    }.bind(this)
                                }), this.setWxConfig(t), wx.ready(function() {
                                    this.setWxConfig(t)
                                }.bind(this))
                            }.bind(i),
                            error: function() {
                                console.log("err")
                            }
                        })
                    }, 1e3))
                }
            }, {
                key: "transverseFullClick",
                value: function() {
                    var e = function() {
                        var e = this.opts.result.data.article.contents.design,
                            t = $(window).width(),
                            a = t / e.width;
                        $(".swiper-slide .page").css("transform", "scale(" + a + ")"), $(".swiper-slide section").css("width", t), $(".swiper-slide section").css("height", a * e.height), R(1 - (this.opts.pageScale = a) + a), document.getElementById("scale-number-full").innerHTML = Math.floor(100 * a) + "%", Math.floor(100 * a) <= 30 ? ($("#reduce-full").addClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduceN.svg "), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg ")) : 200 <= Math.floor(100 * a) ? ($("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), $("#add-full").addClass("active"), $("#add-full").find("img").attr("src", "./images/addN.svg ")) : ($("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg "))
                    }.bind(this);
                    e(), setTimeout(function() {
                        e()
                    }, 30)
                }
            }, {
                key: "portraitFullClick",
                value: function() {
                    var e = function() {
                        var e = this.opts.result.data.article.contents.design,
                            e = $(window).height() / e.height;
                        $(".swiper-slide .page").css("transform", "scale(" + e + ")"), document.getElementById("scale-number-full").innerHTML = Math.floor(100 * e) + "%", $(".swiper-slide section").css("height", $(".swiper-slide section .page")[0].getBoundingClientRect().height), $(".swiper-slide section").css("width", $(".swiper-slide section .page")[0].getBoundingClientRect().width), Math.floor(100 * e) <= 30 ? ($("#reduce-full").addClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduceN.svg "), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg ")) : 200 <= Math.floor(100 * e) ? ($("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), $("#add-full").addClass("active"), $("#add-full").find("img").attr("src", "./images/addN.svg ")) : ($("#reduce-full").removeClass("active"), $("#reduce-full").find("img").attr("src", "./images/reduce.svg "), $("#add-full").removeClass("active"), $("#add-full").find("img").attr("src", "./images/add.svg ")), R(1)
                    }.bind(this);
                    e(), setTimeout(function() {
                        e()
                    }.bind(this), 300)
                }
            }, {
                key: "setWxConfig",
                value: function(e) {
                    var t = e.title,
                        a = e.descText,
                        o = e.link,
                        e = e.imgUrl;
                    (t = $(".title").html()) && "未命名" !== t || (document.title = "找数据，做图表，上镝数！"), wx.updateAppMessageShareData && wx.updateAppMessageShareData({
                        title: t,
                        desc: a,
                        link: o,
                        imgUrl: e,
                        success: function() {}
                    }), wx.updateTimelineShareData && wx.updateTimelineShareData({
                        title: t,
                        desc: a,
                        link: o,
                        imgUrl: e,
                        success: function() {}
                    }), wx.onMenuShareWechat && wx.onMenuShareWechat({
                        title: t,
                        desc: a,
                        link: o,
                        imgUrl: e,
                        success: function(e) {},
                        cancel: function() {}
                    }), wx.onMenuShareTimeline && wx.onMenuShareTimeline({
                        title: t,
                        link: o,
                        imgUrl: e,
                        success: function() {}
                    }), wx.onMenuShareAppMessage && wx.onMenuShareAppMessage({
                        title: t,
                        desc: a,
                        link: o,
                        imgUrl: e,
                        success: function() {},
                        cancel: function() {}
                    }), wx.error(function(e) {
                        console.log(e)
                    })
                }
            }, {
                key: "fullScreen",
                value: function() {
                    var e = document.documentElement;
                    e.requestFullscreen ? e.requestFullscreen() : e.msRequestFullscreen ? e.msRequestFullscreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.webkitRequestFullscreen && e.webkitRequestFullscreen()
                }
            }, {
                key: "exitFullscreen",
                value: function() {
                    document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                }
            }, {
                key: "finishColorListLength",
                value: function(e) {
                    return e.props.colors.list = s(e), e
                }
            }, {
                key: "tbAfterChange",
                value: function(e) {
                    var t = _.cloneDeep(e);
                    if ("cross" === t.templateSwitch) {
                        var a = t.props.map[0],
                            o = t.dataSrc.data[0][0];
                        if (0 === this.removeColIndex) {
                            for (var a = [].concat(k(a.slice(0, 1)), k(a.slice(2))), n = 0, i = 0; i < a.length; i++) a[i].index = n++;
                            t.props.map[0] = a, this.removeColIndex = null
                        }
                        if (o.length < a.length)
                            if (this.removeColIndex) {
                                a = [].concat(k(a.slice(0, this.removeColIndex)), k(a.slice(this.removeColIndex + 1)));
                                for (var r = 0, s = 0; s < a.length; s++) a[s].index = r++;
                                t.props.map[0] = a, this.removeColIndex = null
                            } else if (this.removeAllCol) {
                            if (o.length <= 0) return;
                            var l = [];
                            if (x(t))
                                for (var d = 0; d < o.length; d++) 0 === d ? l.push({
                                    name: "X轴对象",
                                    index: d,
                                    allowType: ["string"],
                                    isLegend: !1,
                                    function: "objCol",
                                    configurable: !0
                                }) : 1 === d ? l.push({
                                    name: "折线列",
                                    index: d,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                }) : l.push({
                                    name: "数值列",
                                    index: d,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                            else if ("154778232785223023" === t.templateId)
                                for (var c = 0; c < o.length; c++) 0 === c ? l.push({
                                    name: "X轴对象",
                                    index: c,
                                    allowType: ["string"],
                                    isLegend: !0,
                                    function: "objCol",
                                    configurable: !0
                                }) : l.push({
                                    name: "数值列",
                                    index: c,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                            else if (-1 < ["3612096174443311121", "3612096174443311122", "3612096174443311123", "7955555777700001207"].indexOf(t.templateId))
                                for (var p = 0; p < o.length; p++) 0 === p ? l.push({
                                    name: "对象",
                                    index: p,
                                    allowType: ["string"],
                                    isLegend: !0,
                                    function: "objCol",
                                    configurable: !0
                                }) : l.push({
                                    name: "数值列",
                                    index: p,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                            else
                                for (var u = 0; u < o.length; u++) 0 === u ? l.push({
                                    name: "X轴对象",
                                    index: u,
                                    allowType: ["string"],
                                    isLegend: !1,
                                    function: "objCol",
                                    configurable: !0
                                }) : l.push({
                                    name: "数值列",
                                    index: u,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                            t.props.map[0] = l
                        } else t.props.map[0] = _.take(a, o.length);
                        else if (o.length > a.length)
                            if ("5544734748594536332" === t.templateId) {
                                for (var h = o.length, m = a.length, g = 0; g < h - m; g++) a.push({
                                    name: "柱图列",
                                    index: a.length,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                                for (var w = 0, f = 0; f < a.length; f++) 1 === f && (a[f].name = "折线列"), a[f].index = w++;
                                t.props.map[0] = a
                            } else {
                                for (var y = o.length - a.length, v = 0; v < y; v++) a.push({
                                    name: "数值列",
                                    index: 0,
                                    allowType: ["number"],
                                    isLegend: !1,
                                    function: "vCol",
                                    configurable: !0
                                });
                                for (var b = 0, C = 0; C < a.length; C++) a[C].index = b++;
                                t.props.map[0] = a
                            }
                        else t.props.map[0] = a
                    }
                    return e.props.map = t.props.map, e
                }
            }, {
                key: "getUserInfo",
                value: function(t) {
                    $.ajax({
                        url: "https://dycharts.com/vis/auth/users/me",
                        type: "GET",
                        success: function(e) {
                            1e3 === e.resultCode ? !(e.data.loginname || e.data.loginname) && (null === t.ctor_lv && "" == t.origin || null === t.ctor_lv && null === t.origin) ? ($(".box-header").css("display", "block"), $("article").css("margin-top", "0.8rem")) : ($(".box-header").css("display", "none"), $("article").css("margin-top", "0"), $(".mask1").css("display", "none")) : null === t.ctor_lv && "" == t.origin || null === t.ctor_lv && null === t.origin ? ($(".box-header").css("display", "block"), $("article").css("margin-top", "0.8rem")) : ($(".box-header").css("display", "none"), $("article").css("margin-top", "0"), $(".mask1").css("display", "none"))
                        }
                    })
                }
            }, {
                key: "setLogoEvent",
                value: function() {
                    var e = this;
                    $(".page-logo-img").on("mousemove", function() {
                        e.opts.result.data.partner_miniwatermark || b() || $(".page-logo-img").attr("src", "./images/right-logo-hover.svg")
                    }), $(".page-logo-img").on("mouseout", function() {
                        e.opts.result.data.partner_miniwatermark || b() || ($(".page-logo-img").attr("src", "./images/right-logo.svg"), $(e).src = "./images/right-logo.svg")
                    }), $(".page-logo-img").on("click", function() {
                        e.opts.result.data.partner_miniwatermark || b() || (b() ? window.location.href = "https://dycharts.com/appv2/#/pages/home/index" : window.open("", "_blank").location.href = "https://dycharts.com/appv2/#/pages/home/index")
                    })
                }
            }, {
                key: "setPageTransform",
                value: function(r) {
                    r = Math.floor(100 * r) / 100, document.getElementById("scale-number").innerHTML = parseInt(100 * r) + "%";
                    var e = function() {
                        var e = this.opts.result.data.article.contents.design,
                            t = $(window).width(),
                            a = 0,
                            o = 0,
                            n = null,
                            i = parseInt(v(location.href).height),
                            n = this.opts.type ? {
                                width: a = 544,
                                height: (o = a / e.width) * e.height
                            } : i ? {
                                width: (o = i / e.height) * e.width,
                                height: i
                            } : {
                                width: a = parseInt(e.width) >= t && !b() ? t - (self != top ? 0 : 24) : b() ? t : e.width,
                                height: (o = a / e.width) * e.height
                            };
                        $(".swiper-slide .page").css("transform", "scale(" + o + ")"), $(".swiper-slide section").css(n), this.opts.pageScale = o, R(r + (1 - o))
                    }.bind(this);
                    e(), setTimeout(function() {
                        e()
                    }, 300)
                }
            }, {
                key: "setPageTransformFull",
                value: function(r) {
                    r = Math.floor(100 * r) / 100, document.getElementById("scale-number-full").innerHTML = 100 * r + "%";
                    var e = function() {
                        var e = this.opts.result.data.article.contents.design,
                            t = $(window).width(),
                            a = 0,
                            o = 0,
                            n = null,
                            i = parseInt(v(location.href).height),
                            n = this.opts.type ? {
                                width: a = 544,
                                height: (o = a / e.width) * e.height
                            } : i ? {
                                width: (o = i / e.height) * e.width,
                                height: i
                            } : {
                                width: a = parseInt(e.width) >= t && !b() ? t - (self != top ? 0 : 24) : b() ? t : e.width,
                                height: (o = a / e.width) * e.height
                            };
                        $(".swiper-slide .page").css("transform", "scale(" + o + ")"), $(".swiper-slide section").css(n), this.opts.pageScale = o, R(r + (1 - o))
                    }.bind(this);
                    e(), setTimeout(function() {
                        e()
                    }, 300)
                }
            }]) && n(e.prototype, t), a && n(e, a), h
        }());

    function R(e) {
        var t = $(".swiper-slide section");
        t.css("transform", "scale(" + e + ")");
        var a = t[0].getBoundingClientRect().width,
            o = t[0].getBoundingClientRect().height,
            n = (D.opts.result.data.article.contents.design, !!(document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement));
        n && "E" === D.opts.result.data.origin && $(".page-logo").hide();
        var i = $(window).width() - (n || self != top ? 0 : 24);
        D.opts.type && (i = $("article").width()), b() ? ($(".swiper-wrapper").css("display", "block"), $(".swiper-wrapper").addClass("swiperBottom"), $(".swiper-slide").addClass("swiperBottom")) : (t[0].getBoundingClientRect().width > i ? (document.querySelector("article").style.width = a + (n ? 0 : 20) + "px", $(".swiper-slide").css("width", a + "px"), $(".swiper-wrapper").css("width", a * $(".swiper-slide section").length + "px"), $(".swiper-wrapper").css("height", o + "px")) : (document.querySelector("article").style.width = "", $(".swiper-slide").css("width", i + "px"), $(".swiper-wrapper").css("width", i * $(".swiper-slide section").length + "px")), document.querySelector("article").style.height = o + (n ? 0 : 24) + "px"), $(".swiper-slide").css("height", t[0].getBoundingClientRect().height + "px"), $(".swiper-wrapper").css("transform", "translate3d(-" + q.activeIndex * $(".swiper-slide").width() + "px, 0px, 0px)"), $(".swiper-wrapper").css("transition-duration", "0s"), setTimeout(function() {
            $(".swiper-wrapper").css("transition-duration", "0.3s")
        }, 300), D.opts.type ? 396 < o ? ($("article").css("padding", "40px 0"), $("article").css("height", o + 80), $("main").css("height", o + 80)) : ($("article").css("padding", ""), $("article").css("height", o), $("main").css("height", o)) : (e = t.width() * e / 2 + 124, $(".swiper-button-prev").css("margin-left", "-" + e + "px"), $(".swiper-button-next").css("margin-right", "-" + e + "px"), e = 2 * e + 20 > $(window).width(), i = t[0].getBoundingClientRect().width > i, e ? ($(".swiper-button-prev").css({
            "margin-top": "-" + (n ? 45.5 : 25) + "px",
            "margin-left": i ? 0 : 61,
            left: "14px"
        }), $(".swiper-button-next").css({
            "margin-top": "-" + (n ? 45.5 : 25) + "px",
            "margin-right": i ? 0 : 61,
            right: "14px"
        })) : ($(".swiper-button-prev").css({
            "margin-top": "-" + (n ? 45.5 : 25) + "px",
            left: "50%"
        }), $(".swiper-button-next").css({
            "margin-top": "-" + (n ? 45.5 : 25) + "px",
            right: "50%"
        })), self != top && ($(".swiper-button-prev").css({
            "margin-top": "-42.5px",
            "margin-left": 0,
            left: "24px"
        }), $(".swiper-button-next").css({
            "margin-top": "-42.5px",
            "margin-right": 0,
            right: "24px"
        })), D.opts.d3ChartAnimestat || A[q.activeIndex].forEach(function(e, t) {
            e && (e.d3Chart.transition(!1), e.d3Chart.update(!0))
        }))
    }

    function P() {
        D.opts.type && ($(".m-thumbs li").removeClass("active"), $(".m-thumbs li").eq(q.activeIndex).addClass("active"), function() {
            var e = parseInt($(".m-thumbs li.active").attr("data-index")) + 1,
                t = $(".m-thumbs li").outerWidth(),
                a = $(".m-thumbs ul").outerWidth(),
                o = $(window).width() - 40,
                n = e * t + 10 * (e - 1),
                t = Math.floor($(".m-thumbs ul").outerWidth() / o),
                e = Math.floor(n / o),
                n = e * o;
            z.translate3d = n, $(".m-thumbs .bt-prev").hide(), $(".m-thumbs .bt-next").show(), 1 <= e && ($(".m-thumbs .bt-prev").show(), $(".m-thumbs .bt-next").show());
            t <= e && 0 != e && (n -= n + o - a, $(".m-thumbs .bt-prev").show(), $(".m-thumbs .bt-next").hide());
            $(".m-thumbs ul").css("transform", "translate3d(-" + n + "px, 0px, 0px)")
        }()), $(".content-wrapper").children().length - 1 == q.activeIndex ? $(".swiper-container .swiper-button-next").hide() : $(".swiper-container .swiper-button-next").show(), 0 == q.activeIndex ? $(".swiper-container .swiper-button-prev").hide() : $(".swiper-container .swiper-button-prev").show(), $(".content-wrapper").children().length <= 1 && ($(".swiper-container .swiper-button-next").hide(), $(".swiper-container .swiper-button-prev").hide()), b() && ($(".swiper-container .swiper-button-next").hide(), $(".swiper-container .swiper-button-prev").hide()), D.opts.currentPageIndex = q.activeIndex, $(".swiper-wrapper").css("transform", "translate3d(-" + q.activeIndex * $(".swiper-slide").width() + "px, 0px, 0px)")
    }

    function H() {
        D.opts.d3ChartAnimestat = !0, A[q.activeIndex].forEach(function(e, t) {
            e && (e.d3Chart.transition(!1), e.d3Chart.update(!0))
        }), A[q.activeIndex].forEach(function(e, t) {
            e && (e.transition && e.d3Chart.transition(e.transition), e.d3Chart.update(!0))
        }), setTimeout(function() {
            D.opts.d3ChartAnimestat = !1
        }, 3e3)
    }
    $(function() {
        $("#phoneInput").blur(function() {
            $("#phoneInput").css({
                border: "none",
                "background-color": "#f7f7f7"
            })
        }), $("#phoneInput").focus(function() {
            $("#phoneInput").css({
                border: "1px solid #0053fa",
                "background-color": "#fff",
                "box-shadow": "none",
                outline: "none"
            })
        })
    }), $("#header-close").click(function() {
        $(".header").css("display", "none"), $("article").css("margin-top", "0")
    }), $(".experience").click(function() {
        $(".mask1").css("display", "block"), window._hmt.push(["_trackEvent", "xshow", "topBanner", "clickLogin"]);
        window._hmt.push(["_trackEvent", "xshow", "showLogin", "countPV", 2])
    }), $("#close").click(function() {
        $(".mask1").css("display", "none"), window._hmt.push(["_trackEvent", "xshow", "showLogin", "closeLogin"])
    }), $("input").focus(function() {
        $(".errortip").css("display", "none")
    }), $(function() {
        var e = $(".mask-code").css("display");
        $(".mask-btn").addClass("disabled"), $("#phoneInput").bind("input porpertychange", function() {
            "" !== $("#phoneInput ").val() && "" !== $("#codeInput ").val() ? ($(".mask-btn").addClass("disabled"), $(".sendCodeBtn").removeClass("disabled1"), $(".mask-btn").removeClass("disabled")) : "" !== $("#phoneInput").val() && "none" === e ? $(".mask-btn").removeClass("disabled") : "" !== $("#phoneInput ").val() && "" === $("#codeInput ").val() ? ($(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), $(".sendCodeBtn").removeClass("disabled1")) : ("" === $("#phoneInput ").val() && $("#codeInput ").val(), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"))
        }), $("#codeInput").bind("input porpertychange", function() {
            "" !== $("#phoneInput ").val() && "" !== $("#codeInput ").val() ? ($(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), $(".sendCodeBtn").removeClass("disabled1"), $(".mask-btn").removeClass("disabled")) : "" !== $("#codeInput ").val() ? $(".mask-btn").removeClass("disabled") : "" !== $("#phoneInput ").val() && "" === $("#codeInput ").val() ? ($(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), $(".sendCodeBtn").removeClass("disabled1")) : ("" === $("#phoneInput ").val() && $("#codeInput ").val(), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"))
        })
    }), $(".getcode").click(function(e) {
        if ("获取验证码" === $(".mask-btn").html()) {
            var t = $("#phoneInput").val();
            if (!t) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号不能为空"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
            if (t.length < 11) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
            if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(t)) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
            $(".errortip:first").css("display", "none"), $(".mask-code").css("display", "block"), $(".getcode").css("display", "none"), $(".login").css("display", "block"), $(".mask-btn").addClass("disabled");
            var a = null,
                o = 60;
            a && (clearInterval(this.codeTimer), a = null), a = setInterval(function() {
                1 <= o ? ($(".sendCodeBtn").html(o + "秒后重新发送"), $(".sendCodeBtn").css({
                    color: "#999999",
                    "pointer-events": "none"
                })) : ($(".sendCodeBtn").html("发送验证码"), clearInterval(a), a = null, $(".sendCodeBtn").css({
                    color: "#005CFA",
                    "pointer-events": "initial"
                })), o--
            }, 1e3), $.ajax({
                url: "".concat(m, "/vis/auth/send_signin_sms_code"),
                type: "POST",
                data: {
                    phoneNo: t
                },
                success: function(e, t) {
                    1e3 !== e.resultCode && ($(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号错误"), $("#phoneNo").addClass("errorStyle"), a && (clearInterval(a), a = null))
                }
            })
        }
    }), "发送验证码" === $(".sendCodeBtn").html() && $(".sendCodeBtn").click(function(e) {
        var t = $("#phoneInput").val();
        if (!t) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号不能为空"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
        if (t.length < 11) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
        if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(t)) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
        $(".errortip:first").css("display", "none"), $(".mask-code").css("display", "block"), $(".getcode").css("display", "none"), $(".login").css("display", "block"), $(".mask-btn").addClass("disabled");
        var a = null,
            o = 60;
        a && (clearInterval(this.codeTimer), a = null), a = setInterval(function() {
            1 <= o ? ($(".sendCodeBtn").html(o + "秒后重新发送"), $(".sendCodeBtn").css({
                color: "#999999",
                "pointer-events": "none"
            })) : ($(".sendCodeBtn").html("发送验证码"), clearInterval(a), a = null, $(".sendCodeBtn").css({
                color: "#005CFA",
                "pointer-events": "initial"
            })), o--
        }, 1e3), $.ajax({
            url: "".concat(m, "/vis/auth/send_signin_sms_code"),
            type: "POST",
            data: {
                phoneNo: t
            },
            success: function(e, t) {
                1e3 !== e.resultCode && ($(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号错误"), $("#phoneNo").addClass("errorStyle"), a && (clearInterval(a), a = null))
            }
        })
    }), $(".login").click(function() {
        window._hmt.push(["_trackEvent", "xshow", "showLogin", "clickLogin"]);
        var e = $("#phoneInput").val(),
            t = $("#codeInput").val();
        if (!e) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号不能为空"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
        if (e.length < 11) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".mask-btn").addClass("disabled"), !1;
        if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(e)) return $(".errortip:first").css("display", "block"), $(".errortip:first").html("请输入正确的手机号"), $(".sendCodeBtn").addClass("disabled1"), $(".mask-btn").addClass("disabled"), !1;
        if ($(".errortip:first").css("display", "none"), $(".sendCodeBtn").removeClass("disabled1"), $(".mask-btn").removeClass("disabled"), !t) return $(".errortip").eq(1).css("display", "block"), $(".errortip").eq(1).html("请输入验证码"), $("#codeInput").addClass("errorStyle"), !1;
        $(".errortip").eq(1).css("display", "none"), $("#codeInput").removeClass("errorStyle");
        t = {
            phoneNo: e,
            validateCode: t
        };
        $.ajax({
            url: "".concat(m, "/vis/auth/signin_by_phone"),
            type: "POST",
            data: t,
            success: function(e) {
                2009 === e.resultCode ? ($(".errortip:first").css("display", "block"), $(".errortip:first").html("手机号错误")) : 2004 === e.resultCode ? ($(".errortip").eq(1).css("display", "block"), $(".errortip").eq(1).html("验证码错误")) : 1e3 === e.resultCode && ($(".box-header").css("display", "none"), $("article").css("margin-top", "0"), $(".mask1").css("display", "none"), e = "登录成功", $("main").append('<div class="mess"><img src="./images/right.svg"><span></span></div>'), $(".mess").fadeIn().find("span").html(e), setTimeout(function() {
                    $(".mess").fadeOut()
                }, 3e3))
            }
        })
    }), $(".m-shade .start").on("click", function() {
        $(".m-shade").removeClass("active"), $(".bgm-audio")[0].play().then(function() {
            $(".bgm-box").addClass("run")
        })
    }), $(".m-shade .close").on("click", function() {
        $(".m-shade").removeClass("active")
    }), $(".m-shade .cancel").on("click", function() {
        $(".m-shade").removeClass("active")
    }), $(".u-gridding").on("click", function() {
        $("#gridding").click()
    }), $("#gridding").on("click", function() {
        M = [], $(".swiper-slide").each(function(e, t) {
            M.push($(t).html())
        }), $(".m-selectPage").show(), $("main").css({
            height: "0",
            overflow: "hidden"
        });
        var e = D.opts.result.data.article.contents.design,
            t = D.opts.result.data.article.contents.pages,
            a = $(window).width(),
            o = 190,
            n = 6;
        e.width < a ? 1600 <= a ? (o = 190, n = 6) : 2560 <= a ? (o = 297, n = 7) : a <= 1440 && (o = 172, n = 5) : 1600 <= a ? (o = 234, n = 5) : 2560 <= a ? (o = 172, n = 6) : a <= 1440 && (o = 350, n = 4);
        var i = 100 / n;
        e.width;
        $(".m-selectPage ul").html(""), t.forEach(function(e, t) {
            var a = "width:" + (i - 2) + "%";
            $(".m-selectPage ul").append('\n        <li  class="' + ((t + 1) % n == 0 ? "mRightNo" : "") + ' " style="' + a + '">\n          <div class="waitSelectBox ' + (q.activeIndex == t ? "active" : "") + '" data-index="' + t + '">\n          ' + M[t] + "\n          </div>\n          <span>" + (t + 1) + "</span>\n        </li>\n    ")
        }), N(), $(".m-selectPage .waitSelectBox").on("click", function() {
            $(".m-selectPage .waitSelectBox").removeClass("active"), $(this).addClass("active"), $("main").css({
                height: "",
                overflow: ""
            }), $(".m-selectPage").hide();
            var e = $(this).attr("data-index");
            q.activeIndex = e, $(".swiper-wrapper").css("transition-duration", "0s"), P(), setTimeout(function() {
                $(".swiper-wrapper").css("transition-duration", "0.3s")
            }, 10), H()
        })
    }), $(".exitSelect").on("click", function() {
        $(".m-selectPage").hide(), $("main").css({
            height: "",
            overflow: ""
        })
    });
    var e = null;

    function N() {
        var e, a, t, o;
        $(".m-selectPage").is(":hidden") || (e = D.opts.result.data.article.contents.design, o = $(window).width(), t = $(".m-selectPage li").width(), a = 6, e.width < o ? 1600 <= o ? a = 6 : 2560 <= o ? a = 7 : o <= 1440 && (a = 5) : 1600 <= o ? a = 5 : 2560 <= o ? a = 6 : o <= 1440 && (a = 4), o = (o = 100) / a, $(".m-selectPage li").removeClass("mRightNo "), $(".m-selectPage li").each(function(e, t) {
            $(this).addClass((e + 1) % a == 0 ? "mRightNo" : "")
        }), $(".m-selectPage li").css({
            width: o - 2.05 + "%"
        }), o = (t = $(".m-selectPage li")[0].getBoundingClientRect().width - 4) / e.width, $(".m-selectPage section").css({
            width: t,
            height: o * e.height,
            transform: "scale(1)"
        }), $(".m-selectPage .page").css({
            transform: "scale(" + o + ")"
        })), P()
    }
    var z = {
        translate3d: 0
    };

    function F() {
        var e = D.opts.result.data.article.contents.design,
            t = $(window).width() - 40,
            a = 160,
            o = $(".swiper-slide").length,
            n = 10 * (o - 1),
            i = 0;
        975 < t && (a += (i = (t = 2500 <= t ? 2500 : t) - 975) / 6);
        var r = 544 + i,
            t = (r = 960 <= r ? 960 : r) / 2 + 14 + 64,
            i = r / e.width,
            r = {
                width: r,
                height: i * e.height
            };
        $(".swiper-slide .page").css("transform", "scale(" + i + ")"), $(".swiper-slide section").css(r), $(".swiper-button-prev").css("margin-left", "-" + t + "px"), $(".swiper-button-next").css("margin-right", "-" + t + "px"), R(1), P(), $(".m-thumbs ul").css({
            width: a * o + n
        }), $(".m-thumbs li").css({
            width: a,
            height: (a + 6) / e.width * e.height
        }), $(".m-thumbs section").css({
            width: a - 6,
            height: (a - 6) / e.width * e.height,
            transform: "scale(1)"
        }), $(".m-thumbs .page").css({
            transform: "scale(" + (a - 6) / e.width + ")"
        })
    }
    $(".m-thumbs .bt-prev").on("click", function() {
        var e = $(window).width() - 40;
        z.translate3d -= e, z.translate3d <= 0 ? (z.translate3d = 0, $(this).hide()) : ($(this).show(), $(".m-thumbs .bt-next").show()), $(".m-thumbs ul").css("transform", "translate3d(-" + z.translate3d + "px, 0px, 0px)")
    }), $(".m-thumbs .bt-next").on("click", function() {
        var e = $(window).width() - 40;
        z.translate3d += e;
        var t = Math.floor($(".m-thumbs ul").outerWidth() / e),
            a = Math.floor(z.translate3d / e),
            o = $(".m-thumbs ul").outerWidth();
        t <= a ? (z.translate3d -= z.translate3d + e - o, $(this).hide()) : ($(this).show(), $(".m-thumbs .bt-prev").show()), $(".m-thumbs ul").css("transform", "translate3d(-" + z.translate3d + "px, 0px, 0px)")
    }), $(window).on("resize", function() {
        clearTimeout(e), e = setTimeout(function() {
            (D.opts.type ? F : N)()
        }, 300)
    })
}();