const pageConfig = {
    usingLocalData: false,
    isSingleChar: false,
    hideToolbar: false
}